import csv,glob,collections,math
basefiles={}
for ver,pat in [('v56','admet_submissions/v56/*.csv'),('v57','admet_submissions/v57/*.csv'),('v73','admet_submissions/v73_v72/*.csv'),('v74','admet_submissions/v74_v73/*.csv'),('v75','admet_submissions/v75_v73/*.csv')]:
 f=glob.glob(pat)[0]; d={}
 with open(f,encoding='utf-8-sig',newline='') as h:
  for r in csv.DictReader(h): d[(r['task'],r['sample_idx'])]=float(r['y_pred'])
 basefiles[ver]=d
print('versions',[(v,len(d)) for v,d in basefiles.items()])
for a,b in [('v56','v73'),('v57','v73'),('v73','v74'),('v73','v75')]:
 print('\n',a,'->',b)
 by=collections.defaultdict(list)
 for k,x in basefiles[a].items():
  z=basefiles[b][k]-x
  if z!=0:by[k[0]].append(z)
 for t,z in sorted(by.items(),key=lambda q:-len(q[1])):
  mae=sum(abs(q) for q in z)/len(z); mu=sum(z)/len(z); sd=(sum((q-mu)**2 for q in z)/len(z))**.5
  print(t,len(z),round(mae,5),round(sd,5))
