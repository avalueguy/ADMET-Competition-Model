# -*- coding: utf-8 -*-
"""共用：赛事参考值 / 评分公式 / 骨架切分 / 数据读取"""
import numpy as np
import pandas as pd
from pathlib import Path
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score, average_precision_score
from rdkit import Chem, RDLogger
from rdkit.Chem.Scaffolds import MurckoScaffold
RDLogger.DisableLog("rdApp.*")

ROOT = Path("/root/autodl-tmp/admet2")
DATA = ROOT / "data_benchmark"
FEAT = ROOT / "features"

REF = {
    "ames": 0.871945, "bbb_martins": 0.927779, "bioavailability_ma": 0.722248,
    "caco2_wang": 0.283647, "clearance_hepatocyte_az": 0.55204,
    "clearance_microsome_az": 0.642814, "cyp2c9_substrate_carbonmangels": 0.44337,
    "cyp2c9_veith": 0.790586, "cyp2d6_substrate_carbonmangels": 0.747531,
    "cyp2d6_veith": 0.719172, "cyp3a4_substrate_carbonmangels": 0.725249,
    "cyp3a4_veith": 0.884121, "dili": 0.908609, "half_life_obach": 0.49139,
    "herg": 0.863358, "hia_hou": 0.99428, "ld50_zhu": 0.603071,
    "lipophilicity_astrazeneca": 0.472895, "pgp_broccatelli": 0.938363,
    "ppbr_az": 7.330617, "solubility_aqsoldb": 0.738443, "vdss_lombardo": 0.660995,
}
METRIC = {
    "ames": "AUROC", "bbb_martins": "AUROC", "bioavailability_ma": "AUROC",
    "caco2_wang": "MAE", "clearance_hepatocyte_az": "Spearman",
    "clearance_microsome_az": "Spearman", "cyp2c9_substrate_carbonmangels": "AUPRC",
    "cyp2c9_veith": "AUPRC", "cyp2d6_substrate_carbonmangels": "AUPRC",
    "cyp2d6_veith": "AUPRC", "cyp3a4_substrate_carbonmangels": "AUROC",
    "cyp3a4_veith": "AUPRC", "dili": "AUROC", "half_life_obach": "Spearman",
    "herg": "AUROC", "hia_hou": "AUROC", "ld50_zhu": "MAE",
    "lipophilicity_astrazeneca": "MAE", "pgp_broccatelli": "AUROC",
    "ppbr_az": "MAE", "solubility_aqsoldb": "MAE", "vdss_lombardo": "Spearman",
}
LOG_TARGET = {"clearance_hepatocyte_az", "clearance_microsome_az",
              "half_life_obach", "vdss_lombardo"}


def score_metric(y, p, metric):
    y = np.asarray(y, float); p = np.asarray(p, float)
    if metric in ("AUROC", "AUPRC"):
        if len(np.unique(y)) < 2:
            return float("nan")
        return roc_auc_score(y, p) if metric == "AUROC" else average_precision_score(y, p)
    if metric == "Spearman":
        r = spearmanr(y, p).correlation
        return float(r) if np.isfinite(r) else float("nan")
    return float(np.mean(np.abs(y - p)))


def comp_score(raw, metric, ref):
    if raw is None or not np.isfinite(raw):
        return 50.0
    if metric == "MAE":
        return 50.0 + 25.0 * np.log(max(ref, 1e-9) / max(raw, 1e-9))
    if metric == "Spearman":
        return 50.0 + 25.0 * np.log((1.0 + raw) / (1.0 + ref))
    return 50.0 + 25.0 * np.log(max(raw, 1e-9) / max(ref, 1e-9))


def load_task(task):
    def rd(part):
        df = pd.read_csv(DATA / task / f"{part}.csv")
        df.columns = [c.strip().strip('"') for c in df.columns]
        return df
    return rd("train"), rd("valid"), rd("test")


_SCAF_CACHE = {}


def scaffold_key(smi):
    if smi in _SCAF_CACHE:
        return _SCAF_CACHE[smi]
    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        k = "BAD_" + str(smi)
    else:
        try:
            k = MurckoScaffold.MurckoScaffoldSmiles(mol=mol, includeChirality=False)
        except Exception:
            k = "ERR_" + str(smi)
    _SCAF_CACHE[smi] = k
    return k


def scaffold_folds(smiles, y, nfold=5, seed=7, kind="reg"):
    """骨架切分；分类任务若某折单一类别则退回分层随机"""
    keys = [scaffold_key(s) for s in smiles]
    groups = {}
    for i, k in enumerate(keys):
        groups.setdefault(k, []).append(i)
    rng = np.random.RandomState(seed)
    gs = list(groups.values())
    rng.shuffle(gs)
    gs.sort(key=len, reverse=True)
    folds = [[] for _ in range(nfold)]
    sizes = [0] * nfold
    for g in gs:
        j = int(np.argmin(sizes))
        folds[j].extend(g); sizes[j] += len(g)
    out = []
    y = np.asarray(y)
    for f in range(nfold):
        va = np.array(sorted(folds[f]), dtype=np.int64)
        tr = np.array(sorted(set(range(len(smiles))) - set(folds[f])), dtype=np.int64)
        out.append((tr, va))
    need_fallback = False
    if kind == "cls":
        for tr_i, va_i in out:
            if len(np.unique(y[va_i])) < 2:
                need_fallback = True
    if need_fallback:
        from sklearn.model_selection import StratifiedKFold
        out = [(tr, va) for tr, va in StratifiedKFold(nfold, shuffle=True, random_state=seed)
               .split(np.zeros(len(smiles)), y)]
    return out, ("stratified" if need_fallback else "scaffold")
