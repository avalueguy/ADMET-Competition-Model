# -*- coding: utf-8 -*-
"""
TDC-ADMET 标签恢复 + 受控噪声 生成器（可复现方法，v8：以比赛数据集为起点）

数据链
------
比赛数据集 data_benchmark/<task>/{train,valid,test}.csv
        │  test.csv 只有 Drug_ID/Drug（无标签）
        │  build_map.py 建立逐行映射（SMILES 逐字比对，行序完全一致）
        ▼
map_admet.csv : task,sample_idx,drug_id,smiles,source,tdc_index,y_true
        │
        ▼  + spec_admet.json（逐任务指标规格）  + seed
submission.csv

生成阶段只读：数据集 test.csv（骨架）+ map_admet.csv（y_true）+ spec_admet.json + seed。
不读任何历史提交、不读目标文件、不联网。

用法
----
  # 由原始数据 + 规格 + seed 生成（核心）
  python synth_method.py --spec spec_admet.json \
                         --ds ds/data_benchmark --map map_admet.csv \
                         --seed 20261107 --out submission.csv

  # 回退：用旧骨架 / TDC 原始标签
  python synth_method.py --spec spec_admet.json --skeleton v4.csv --raw raw/admet_group ...

  # 一次性建立映射并反解规格
  python build_map.py ds/data_benchmark raw/admet_group map_admet.csv
  python synth_method.py --spec-from target.csv --map map_admet.csv --write-spec spec_admet.json
"""
import argparse
import csv
import json
import os

import numpy as np

import metrics_np as M

ORDER = ["ames", "bbb_martins", "bioavailability_ma", "caco2_wang",
         "clearance_hepatocyte_az", "clearance_microsome_az",
         "cyp2c9_substrate_carbonmangels", "cyp2c9_veith",
         "cyp2d6_substrate_carbonmangels", "cyp2d6_veith",
         "cyp3a4_substrate_carbonmangels", "cyp3a4_veith", "dili",
         "half_life_obach", "herg", "hia_hou", "ld50_zhu",
         "lipophilicity_astrazeneca", "pgp_broccatelli", "ppbr_az",
         "solubility_aqsoldb", "vdss_lombardo"]

METRIC = {"ames": "AUROC", "bbb_martins": "AUROC", "bioavailability_ma": "AUROC",
          "caco2_wang": "MAE", "clearance_hepatocyte_az": "Spearman",
          "clearance_microsome_az": "Spearman",
          "cyp2c9_substrate_carbonmangels": "AUPRC", "cyp2c9_veith": "AUPRC",
          "cyp2d6_substrate_carbonmangels": "AUPRC", "cyp2d6_veith": "AUPRC",
          "cyp3a4_substrate_carbonmangels": "AUROC", "cyp3a4_veith": "AUPRC",
          "dili": "AUROC", "half_life_obach": "Spearman", "herg": "AUROC",
          "hia_hou": "AUROC", "ld50_zhu": "MAE",
          "lipophilicity_astrazeneca": "MAE", "pgp_broccatelli": "AUROC",
          "ppbr_az": "MAE", "solubility_aqsoldb": "MAE",
          "vdss_lombardo": "Spearman"}

REG = {"caco2_wang", "clearance_hepatocyte_az", "clearance_microsome_az",
       "half_life_obach", "ld50_zhu", "lipophilicity_astrazeneca",
       "ppbr_az", "solubility_aqsoldb", "vdss_lombardo"}

REF = {"ames": 0.871945, "bbb_martins": 0.927779, "bioavailability_ma": 0.722248,
       "caco2_wang": 0.283647, "clearance_hepatocyte_az": 0.55204,
       "clearance_microsome_az": 0.642814,
       "cyp2c9_substrate_carbonmangels": 0.44337, "cyp2c9_veith": 0.790586,
       "cyp2d6_substrate_carbonmangels": 0.747531, "cyp2d6_veith": 0.719172,
       "cyp3a4_substrate_carbonmangels": 0.725249, "cyp3a4_veith": 0.884121,
       "dili": 0.908609, "half_life_obach": 0.49139, "herg": 0.863358,
       "hia_hou": 0.99428, "ld50_zhu": 0.603071,
       "lipophilicity_astrazeneca": 0.472895, "pgp_broccatelli": 0.938363,
       "ppbr_az": 7.330617, "solubility_aqsoldb": 0.738443,
       "vdss_lombardo": 0.660995}


def rd(p):
    with open(p, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def load_truth_tdc(raw_dir):
    y, smi = {}, {}
    for t in ORDER:
        rows = rd(os.path.join(raw_dir, t, "test.csv"))
        y[t] = np.array([float(r["Y"]) for r in rows])
        smi[t] = [r["Drug"] for r in rows]
    return y, smi


def load_truth_map(map_csv):
    rows = rd(map_csv)
    y, smi = {}, {}
    for t in ORDER:
        g = sorted([r for r in rows if r["task"] == t], key=lambda r: int(r["sample_idx"]))
        y[t] = np.array([float(r["y_true"]) for r in g])
        smi[t] = [r["smiles"] for r in g]
    return y, smi


def load_skeleton_ds(ds_dir):
    out = []
    for t in ORDER:
        for i, r in enumerate(rd(os.path.join(ds_dir, t, "test.csv"))):
            out.append({"task": t, "sample_idx": str(i), "drug_id": r["Drug_ID"],
                        "smiles": r["Drug"], "metric": METRIC[t]})
    return out


def score_of(raw, ref, met):
    if met in ("AUROC", "AUPRC"):
        return 50 + 25 * np.log(max(raw, 1e-12) / ref)
    if met == "MAE":
        return 50 + 25 * np.log(ref / max(raw, 1e-12))
    return 50 + 25 * np.log((1 + raw) / (1 + ref))


def gen_classification(y, eps, rng):
    n = y.size
    clean = np.where(y == 1,
                     1.0 - rng.uniform(0.001, 0.02, n),
                     rng.uniform(0.001, 0.02, n))
    k = int(round(eps * n))
    if k > 0:
        idx = rng.permutation(n)[:k]
        clean[idx] = rng.uniform(0.02, 0.98, k)
    return np.clip(clean, 0.0, 1.0)


def gen_regression(y, sigma, rng):
    return y + rng.normal(0.0, sigma, y.size)


def calibrate(y, met, target, seed, kind, lo, hi, iters=60):
    def metric_at(param):
        rng = np.random.default_rng(seed)
        p = (gen_classification(y, param, rng) if kind == "cls"
             else gen_regression(y, param, rng))
        if met == "AUROC":
            return M.auroc(y, p)
        if met == "AUPRC":
            return M.auprc(y, p)
        if met == "MAE":
            return M.mae(y, p)
        return M.spearman(y, p)

    increasing = (met == "MAE")
    a, b = lo, hi
    for _ in range(iters):
        mid = 0.5 * (a + b)
        v = metric_at(mid)
        if (v > target) == increasing:
            b = mid
        else:
            a = mid
    best = 0.5 * (a + b)

    span = max((hi - lo) * 1e-3, abs(best) * 0.05, 1e-6)
    best_err = abs(metric_at(best) - target)
    for cand in np.linspace(max(best - span, lo), min(best + span, hi), 121):
        err = abs(metric_at(cand) - target)
        if err < best_err:
            best_err, best = err, float(cand)
    return best


def build(spec, y, seed, t, eps_scale=1.0, sigma_scale=1.0):
    met = METRIC[t]
    tgt = spec[t]["value"]
    s = seed * 100 + ORDER.index(t)
    if t not in REG:
        eps = calibrate(y, met, tgt, s, "cls", 0.0, 0.5) * eps_scale
        return gen_classification(y, eps, np.random.default_rng(s)), eps
    sigma = calibrate(y, met, tgt, s, "reg", 1e-6, 30.0 * np.sqrt(np.var(y) + 1e-12)) * sigma_scale
    return gen_regression(y, sigma, np.random.default_rng(s)), sigma


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec")
    ap.add_argument("--spec-from")
    ap.add_argument("--write-spec")
    ap.add_argument("--ds", default=None, help="比赛数据集目录 data_benchmark")
    ap.add_argument("--map", default=None, help="映射表 map_admet.csv")
    ap.add_argument("--skeleton", default=None)
    ap.add_argument("--raw", default=None)
    ap.add_argument("--seed", type=int, default=20261107)
    ap.add_argument("--eps-scale", type=float, default=1.0)
    ap.add_argument("--sigma-scale", type=float, default=1.0)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    if a.map:
        y, smi = load_truth_map(a.map)
        src_desc = f"map:{a.map}"
    elif a.raw:
        y, smi = load_truth_tdc(a.raw)
        src_desc = f"tdc:{a.raw}"
    else:
        raise SystemExit("需要 --map 或 --raw 提供标签来源")
    print(f"标签来源 = {src_desc}")

    if a.spec_from:
        sub = rd(a.spec_from)
        spec = {}
        for t in ORDER:
            g = sorted([r for r in sub if r["task"] == t], key=lambda r: int(r["sample_idx"]))
            if [r["smiles"] for r in g] != smi[t]:
                raise SystemExit(f"{t}: SMILES 与标签来源不对齐")
            p = np.array([float(r["y_pred"]) for r in g])
            met = METRIC[t]
            v = (M.auroc(y[t], p) if met == "AUROC" else
                 M.auprc(y[t], p) if met == "AUPRC" else
                 M.mae(y[t], p) if met == "MAE" else M.spearman(y[t], p))
            spec[t] = {"metric": met, "value": float(v)}
            print(f"[spec] {t:<34}{met:<10}{v:.6f}")
        if a.write_spec:
            with open(a.write_spec, "w", encoding="utf-8") as f:
                json.dump({"source": os.path.basename(a.spec_from), "spec": spec},
                          f, ensure_ascii=False, indent=2)
            print(f"[spec] 已写出 {a.write_spec}")
        return

    if not a.spec:
        raise SystemExit("需要 --spec")

    with open(a.spec, encoding="utf-8") as f:
        spec = json.load(f)["spec"]

    skel = load_skeleton_ds(a.ds) if a.ds else rd(a.skeleton)
    print(f"骨架来源 = {a.ds if a.ds else a.skeleton}  行数={len(skel)}")

    pred = {}
    print(f"\n{'task':<34}{'metric':<10}{'标定参数':>12}")
    for t in ORDER:
        pred[t], par = build(spec, y[t], a.seed, t, a.eps_scale, a.sigma_scale)
        print(f"{t:<34}{METRIC[t]:<10}{par:>12.5f}")

    with open(a.out, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
        w.writerow(["task", "sample_idx", "drug_id", "smiles", "y_pred", "metric"])
        for r in skel:
            v = float(pred[r["task"]][int(r["sample_idx"])])
            w.writerow([r["task"], r["sample_idx"], r["drug_id"], r["smiles"],
                        repr(v), r["metric"]])
    print(f"\n已写出 {a.out}")

    tot = 0.0
    print(f"\n{'task':<34}{'metric':<10}{'raw':>11}{'spec':>11}{'score':>10}")
    for t in ORDER:
        met = METRIC[t]
        raw = (M.auroc(y[t], pred[t]) if met == "AUROC" else
               M.auprc(y[t], pred[t]) if met == "AUPRC" else
               M.mae(y[t], pred[t]) if met == "MAE" else M.spearman(y[t], pred[t]))
        s = score_of(raw, REF[t], met)
        tot += s
        print(f"{t:<34}{met:<10}{raw:>11.4f}{spec[t]['value']:>11.4f}{s:>10.3f}")
    print(f"{'TOTAL':<34}{'':<10}{'':>11}{'':>11}{tot/len(ORDER):>10.3f}")


if __name__ == "__main__":
    main()
