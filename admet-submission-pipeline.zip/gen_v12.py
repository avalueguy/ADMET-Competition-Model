# -*- coding: utf-8 -*-
"""生成逐任务混合提交：v4_score >= 53 用 v4，否则用 v10"""
import csv
import os
import numpy as np
from synth_method import ORDER

V4_SCORE = {
    "ames": 50.30, "bbb_martins": 49.91, "bioavailability_ma": 52.39,
    "caco2_wang": 51.35, "clearance_hepatocyte_az": 50.21, "clearance_microsome_az": 50.50,
    "cyp2c9_substrate_carbonmangels": 56.94, "cyp2c9_veith": 51.36,
    "cyp2d6_substrate_carbonmangels": 50.36, "cyp2d6_veith": 50.85,
    "cyp3a4_substrate_carbonmangels": 50.71, "cyp3a4_veith": 50.38,
    "dili": 50.72, "half_life_obach": 52.54, "herg": 49.94, "hia_hou": 50.05,
    "ld50_zhu": 52.07, "lipophilicity_astrazeneca": 53.26, "pgp_broccatelli": 50.28,
    "ppbr_az": 53.22, "solubility_aqsoldb": 51.40, "vdss_lombardo": 50.89,
}
THR = 53.0


def load(p):
    d = {}
    with open(p, newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            d.setdefault(r["task"], {})[int(r["sample_idx"])] = r
    return d


v10 = load("v10_sub.csv")
mdl = load("v4.csv")

out = "v12_per_task.csv"
with open(out, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
    w.writerow(["task", "sample_idx", "drug_id", "smiles", "y_pred", "metric"])
    for t in ORDER:
        src = mdl if V4_SCORE[t] >= THR else v10
        for k in sorted(src[t].keys()):
            row = src[t][k]
            w.writerow([t, k, row["drug_id"], row["smiles"], row["y_pred"], row["metric"]])

n_v4 = sum(1 for t in ORDER if V4_SCORE[t] >= THR)
print(f"written {out}: v4任务={n_v4}  v10任务={22-n_v4}")
