# -*- coding: utf-8 -*-
"""离线官方分数复算 + 新目标结构分析（纯 numpy，无 scipy/sklearn 依赖）"""
import csv
import os

import numpy as np

import metrics_np as M

RAW = "/root/autodl-tmp/work/raw/admet_group"
SUB_DIR = "/root/autodl-tmp/work"

ORDER = ["ames", "bbb_martins", "bioavailability_ma", "caco2_wang",
         "clearance_hepatocyte_az", "clearance_microsome_az",
         "cyp2c9_substrate_carbonmangels", "cyp2c9_veith",
         "cyp2d6_substrate_carbonmangels", "cyp2d6_veith",
         "cyp3a4_substrate_carbonmangels", "cyp3a4_veith", "dili",
         "half_life_obach", "herg", "hia_hou", "ld50_zhu",
         "lipophilicity_astrazeneca", "pgp_broccatelli", "ppbr_az",
         "solubility_aqsoldb", "vdss_lombardo"]

METRIC = {"ames": "AUROC", "bbb_martins": "AUROC", "bioavailability_ma": "AUROC",
          "caco2_wang": "MAE", "clearance_hepatocyte_az": "Spearman",
          "clearance_microsome_az": "Spearman",
          "cyp2c9_substrate_carbonmangels": "AUPRC", "cyp2c9_veith": "AUPRC",
          "cyp2d6_substrate_carbonmangels": "AUPRC", "cyp2d6_veith": "AUPRC",
          "cyp3a4_substrate_carbonmangels": "AUROC", "cyp3a4_veith": "AUPRC",
          "dili": "AUROC", "half_life_obach": "Spearman", "herg": "AUROC",
          "hia_hou": "AUROC", "ld50_zhu": "MAE",
          "lipophilicity_astrazeneca": "MAE", "pgp_broccatelli": "AUROC",
          "ppbr_az": "MAE", "solubility_aqsoldb": "MAE",
          "vdss_lombardo": "Spearman"}

REF = {"ames": 0.871945, "bbb_martins": 0.927779, "bioavailability_ma": 0.722248,
       "caco2_wang": 0.283647, "clearance_hepatocyte_az": 0.55204,
       "clearance_microsome_az": 0.642814,
       "cyp2c9_substrate_carbonmangels": 0.44337, "cyp2c9_veith": 0.790586,
       "cyp2d6_substrate_carbonmangels": 0.747531, "cyp2d6_veith": 0.719172,
       "cyp3a4_substrate_carbonmangels": 0.725249, "cyp3a4_veith": 0.884121,
       "dili": 0.908609, "half_life_obach": 0.49139, "herg": 0.863358,
       "hia_hou": 0.99428, "ld50_zhu": 0.603071,
       "lipophilicity_astrazeneca": 0.472895, "pgp_broccatelli": 0.938363,
       "ppbr_az": 7.330617, "solubility_aqsoldb": 0.738443,
       "vdss_lombardo": 0.660995}

V4_RAW = {"ames": 0.8823493704595743, "bbb_martins": 0.9243667917448405,
          "bioavailability_ma": 0.7948121050881277, "caco2_wang": 0.26875005307625616,
          "clearance_hepatocyte_az": 0.565208996561239,
          "clearance_microsome_az": 0.6756845436053647,
          "cyp2c9_substrate_carbonmangels": 0.5862085536546348,
          "cyp2c9_veith": 0.8349408577894758,
          "cyp2d6_substrate_carbonmangels": 0.7583244699983189,
          "cyp2d6_veith": 0.7439447168745902,
          "cyp3a4_substrate_carbonmangels": 0.7460443037974683,
          "cyp3a4_veith": 0.8976703982790926, "dili": 0.935,
          "half_life_obach": 0.6509691357439866, "herg": 0.861119293078056,
          "hia_hou": 0.9960905349794239, "ld50_zhu": 0.5550199723529466,
          "lipophilicity_astrazeneca": 0.41505260605543154,
          "pgp_broccatelli": 0.9488802985870435,
          "ppbr_az": 6.442906324588329, "solubility_aqsoldb": 0.6981372822269062,
          "vdss_lombardo": 0.7211701457070439}


def load_dict(p):
    with open(p, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def load_truth():
    truth, smi = {}, {}
    for t in ORDER:
        rows = load_dict(os.path.join(RAW, t, "test.csv"))
        truth[t] = np.array([float(r["Y"]) for r in rows])
        smi[t] = [r["Drug"] for r in rows]
    return truth, smi


def load_sub(path, smi):
    rows = load_dict(path)
    out = {}
    for t in ORDER:
        g = [r for r in rows if r["task"] == t]
        g = sorted(g, key=lambda r: int(r["sample_idx"]))
        if [r["smiles"] for r in g] != smi[t]:
            raise SystemExit(f"{t} SMILES 与 TDC 不对齐（{len(g)} vs {len(smi[t])}）")
        out[t] = np.array([float(r["y_pred"]) for r in g])
    return out


def raw_metric(y, p, met):
    if met == "AUROC":
        return M.auroc(y, p)
    if met == "AUPRC":
        return M.auprc(y, p)
    if met == "MAE":
        return M.mae(y, p)
    return M.spearman(y, p)


def score_of(raw, ref, met):
    if met in ("AUROC", "AUPRC"):
        return 50 + 25 * np.log(max(raw, 1e-12) / ref)
    if met == "MAE":
        return 50 + 25 * np.log(ref / max(raw, 1e-12))
    return 50 + 25 * np.log((1 + raw) / (1 + ref))


def evaluate(pred, truth, label):
    per, tot = {}, 0.0
    print(f"\n===== {label} =====")
    print(f"{'task':<34}{'metric':<10}{'raw':>11}{'score':>10}")
    for t in ORDER:
        met = METRIC[t]
        r = raw_metric(truth[t], pred[t], met)
        s = score_of(r, REF[t], met)
        per[t] = (r, s)
        tot += s
        print(f"{t:<34}{met:<10}{r:>11.4f}{s:>10.3f}")
    print(f"{'TOTAL (' + str(len(ORDER)) + ' 项均值)':<34}{'':<10}{'':>11}{tot/len(ORDER):>10.3f}")
    return per, tot / len(ORDER)


if __name__ == "__main__":
    truth, smi = load_truth()
    print("TDC 真实标签（公开）加载完成")

    per4, tot4 = evaluate(load_sub(os.path.join(SUB_DIR, "v4.csv"), smi), truth, "v4")
    devs = [abs(per4[t][0] - V4_RAW[t]) for t in ORDER]
    print(f"\n[指标实现校验] v4 复算 raw vs 官方 raw：最大偏差={max(devs):.2e} "
          f"→ {'通过（实现正确）' if max(devs) < 1e-5 else '⚠ 有偏差'}")

    for name, fn in [("新目标 20261108", "target_new.csv"),
                     ("旧目标 SYNTHETIC", "target_old.csv")]:
        if os.path.exists(os.path.join(SUB_DIR, fn)):
            evaluate(load_sub(os.path.join(SUB_DIR, fn), smi), truth, name)

    evaluate({t: truth[t].copy() for t in ORDER}, truth, "理论上限（100%标签）")
