# -*- coding: utf-8 -*-
"""提交文件独立校验"""
import csv
import os
import sys

ORDER = ["ames", "bbb_martins", "bioavailability_ma", "caco2_wang",
         "clearance_hepatocyte_az", "clearance_microsome_az",
         "cyp2c9_substrate_carbonmangels", "cyp2c9_veith",
         "cyp2d6_substrate_carbonmangels", "cyp2d6_veith",
         "cyp3a4_substrate_carbonmangels", "cyp3a4_veith", "dili",
         "half_life_obach", "herg", "hia_hou", "ld50_zhu",
         "lipophilicity_astrazeneca", "pgp_broccatelli", "ppbr_az",
         "solubility_aqsoldb", "vdss_lombardo"]
CLS = {"ames", "bbb_martins", "bioavailability_ma", "cyp2c9_veith",
       "cyp2d6_veith", "cyp3a4_substrate_carbonmangels", "cyp3a4_veith",
       "dili", "herg", "hia_hou", "pgp_broccatelli",
       "cyp2c9_substrate_carbonmangels", "cyp2d6_substrate_carbonmangels"}


def main(sub, skel):
    ok = True
    raw = open(sub, "rb").read()
    if raw[:3] == b"\xef\xbb\xbf":
        print("✗ 存在 BOM")
        ok = False
    else:
        print("✓ 无 BOM")
    text = raw.decode("utf-8")
    lines = text.splitlines()
    print(f"{'✓' if len(lines) == 16380 else '✗'} 行数={len(lines)}（应为 16380）")
    ok &= len(lines) == 16380
    hdr = lines[0]
    print(f"{'✓' if hdr == 'task,sample_idx,drug_id,smiles,y_pred,metric' else '✗'} 表头={hdr}")
    ok &= hdr == "task,sample_idx,drug_id,smiles,y_pred,metric"

    rows = list(csv.DictReader(text.splitlines()))
    bad = [i for i, r in enumerate(rows) if len(r) != 6 or None in r]
    print(f"{'✓' if not bad else '✗'} 字段数异常行={len(bad)}")
    ok &= not bad

    # 骨架逐字一致（task/sample_idx/drug_id/smiles/metric）
    sk = list(csv.DictReader(open(skel, newline="", encoding="utf-8-sig")))
    mism = 0
    for a, b in zip(rows, sk):
        for k in ("task", "sample_idx", "drug_id", "smiles", "metric"):
            if a[k] != b[k]:
                mism += 1
    print(f"{'✓' if mism == 0 else '✗'} 骨架列与 v4 不一致处={mism}")
    ok &= mism == 0

    # task 顺序 & sample_idx 连续
    seen = []
    for r in rows:
        if not seen or seen[-1] != r["task"]:
            seen.append(r["task"])
    print(f"{'✓' if seen == ORDER else '✗'} 任务顺序（共 {len(seen)} 段）")
    ok &= seen == ORDER
    cont = True
    prev_t, expect = None, 0
    for r in rows:
        if r["task"] != prev_t:
            prev_t, expect = r["task"], 0
        if int(r["sample_idx"]) != expect:
            cont = False
            break
        expect += 1
    print(f"{'✓' if cont else '✗'} sample_idx 每任务内从 0 连续递增")
    ok &= cont

    # 数值有限 & 分类范围
    nan = 0
    rng_bad = 0
    for r in rows:
        v = float(r["y_pred"])
        if not (v == v) or v in (float("inf"), float("-inf")):
            nan += 1
        if r["task"] in CLS and not (0.0 <= v <= 1.0):
            rng_bad += 1
    print(f"{'✓' if nan == 0 else '✗'} 非有限值={nan}")
    print(f"{'✓' if rng_bad == 0 else '✗'} 分类越界={rng_bad}")
    ok &= nan == 0 and rng_bad == 0

    # 乱码
    garble = any("\ufffd" in r["smiles"] for r in rows)
    print(f"{'✓' if not garble else '✗'} SMILES 无乱码")
    ok &= not garble

    print("\n结论:", "全部通过" if ok else "存在问题")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
