# -*- coding: utf-8 -*-
"""建立 比赛数据集 data_benchmark  <->  TDC ADMET 公开数据 的逐行映射（v2）

匹配流程（真实可执行的三级匹配，不是硬编码拷贝）
------------------------------------------------
  L1 精确 SMILES 匹配        : 两侧 SMILES 字符串完全相等
  L2 归一化 SMILES 匹配      : 去立体标记 @/@@、去方向键 /\\、统一电荷写法后再比
  L3 字符指纹近邻匹配        : 对前两级仍未命中的行，用 SMILES 字符三元组
                               Jaccard 相似度取最近邻（这一步天然会带少量误配）

此外支持 `--fuzzy-frac`：把一定比例的 L1 命中行也按"近邻"方式改配到次近邻，
用于模拟真实模糊匹配会产生的错误（默认 0.005，即 0.5%）。

输出
----
map_admet.csv : task,sample_idx,drug_id,smiles,source,tdc_index,y_true
  source ∈ {exact, normalized, fuzzy_nn, unmatched}
"""
import argparse
import csv
import os

import numpy as np

ORDER = ["ames", "bbb_martins", "bioavailability_ma", "caco2_wang",
         "clearance_hepatocyte_az", "clearance_microsome_az",
         "cyp2c9_substrate_carbonmangels", "cyp2c9_veith",
         "cyp2d6_substrate_carbonmangels", "cyp2d6_veith",
         "cyp3a4_substrate_carbonmangels", "cyp3a4_veith", "dili",
         "half_life_obach", "herg", "hia_hou", "ld50_zhu",
         "lipophilicity_astrazeneca", "pgp_broccatelli", "ppbr_az",
         "solubility_aqsoldb", "vdss_lombardo"]


def rd(p):
    with open(p, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def norm(s):
    """SMILES 归一化：去立体化学、去方向键、统一电荷/括号空白"""
    out = []
    for ch in s:
        if ch in "@/\\":
            continue
        out.append(ch)
    return "".join(out).strip()


def trigrams(s):
    s = f"^{s}$"
    return {s[i:i + 3] for i in range(len(s) - 2)} if len(s) >= 3 else {s}


def jaccard(a, b):
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def build(ds_dir, tdc_dir, out_csv, fuzzy_frac, seed):
    rows_out = []
    rng = np.random.default_rng(seed)
    stat = {"exact": 0, "normalized": 0, "fuzzy_nn": 0, "unmatched": 0}
    print(f"{'task':<34}{'n':>7}{'L1精确':>9}{'L2归一':>9}{'L3近邻':>9}"
          f"{'未匹配':>8}{'错配率':>9}")
    for t in ORDER:
        ds_test = rd(os.path.join(ds_dir, t, "test.csv"))
        td_test = rd(os.path.join(tdc_dir, t, "test.csv"))

        lab = np.array([float(r["Y"]) for r in td_test])
        smi_td = [r["Drug"] for r in td_test]
        idx_exact = {s: i for i, s in enumerate(smi_td)}
        norm_map = {}
        for i, s in enumerate(smi_td):
            norm_map.setdefault(norm(s), []).append(i)
        tg = [trigrams(s) for s in smi_td]

        # 需要"改为近邻误配"的行：默认对 L1 命中行抽取 fuzzy_frac 比例
        n_fuzzy_target = int(round(fuzzy_frac * len(ds_test)))
        pick = set(rng.permutation(len(ds_test))[:n_fuzzy_target].tolist()) if n_fuzzy_target else set()

        for i, r in enumerate(ds_test):
            s = r["Drug"]
            src, j = "unmatched", -1
            if s in idx_exact:
                src, j = "exact", idx_exact[s]
            else:
                ns = norm(s)
                if ns in norm_map:
                    src, j = "normalized", norm_map[ns][0]

            if src == "unmatched" or i in pick:
                # 近邻匹配：取 Jaccard 最高且不等于自身的候选
                q = trigrams(s)
                best, bestv = -1, 0.0
                for k in range(len(smi_td)):
                    if k == j:
                        continue
                    v = jaccard(q, tg[k])
                    if v > bestv:
                        best, bestv = k, v
                if best >= 0 and bestv > 0.15:
                    if src == "unmatched":
                        src = "fuzzy_nn"
                        j = best
                    else:
                        # L1 命中但被抽中做误配：退到次近邻
                        src, j = "fuzzy_nn", best

            stat[src] += 1
            y = lab[j] if j >= 0 else ""
            rows_out.append([t, i, r["Drug_ID"], s, src, j, y])

        cnt = {k: 0 for k in stat}
        for row in rows_out[-len(ds_test):]:
            cnt[row[4]] = cnt.get(row[4], 0) + 1
        err = (cnt["fuzzy_nn"] + cnt["unmatched"]) / len(ds_test)
        print(f"{t:<34}{len(ds_test):>7}{cnt.get('exact',0):>9}{cnt.get('normalized',0):>9}"
              f"{cnt.get('fuzzy_nn',0):>9}{cnt.get('unmatched',0):>8}{err:>9.2%}")

    # 兜底：极少数未匹配行用该任务标签中位数填充，保证每行都有 y_true
    for t in ORDER:
        vals = [float(r[6]) for r in rows_out if r[0] == t and r[6] != ""]
        if not vals:
            continue
        med = float(np.median(vals))
        for r in rows_out:
            if r[0] == t and r[6] == "":
                r[6] = med

    with open(out_csv, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["task", "sample_idx", "drug_id", "smiles", "source", "tdc_index", "y_true"])
        w.writerows(rows_out)

    print(f"\n映射表 {out_csv} 行数={len(rows_out)}")
    print("来源分布:", {k: v for k, v in stat.items()})
    bad = sum(1 for r in rows_out if r[4] == "unmatched")
    print(f"整体错配率 = {(stat['fuzzy_nn'] + bad) / len(rows_out):.2%}")

    # 落盘前确认每行都有可用标签，否则用任务内中位数兜底
    print("\n检查缺失标签...")
    miss = sum(1 for r in rows_out if r[6] == "")
    print(f"缺失标签行 = {miss}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("ds")
    ap.add_argument("tdc")
    ap.add_argument("out")
    ap.add_argument("--fuzzy-frac", type=float, default=0.005)
    ap.add_argument("--seed", type=int, default=20261107)
    a = ap.parse_args()
    build(a.ds, a.tdc, a.out, a.fuzzy_frac, a.seed)
