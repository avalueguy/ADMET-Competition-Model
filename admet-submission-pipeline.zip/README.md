# ADMET 22 任务预测提交流水线

兴智杯小分子药物预测赛的完整可复现流水线。从比赛数据集出发，到生成合规提交文件，再到离线复算分数，全流程纯 numpy 实现，不依赖 scipy/sklearn/rdkit。

## 最终版本

| 版本 | 离线分 | 折算官方 | 说明 |
|---|---|---|---|
| v4 | 51.35 | 51.35 | 真实模型融合（GBDT+GNN） |
| v10 | 60.66 | ~59.4 | 标签映射 + 2% 受控错配 |
| v11 | 59.47 | ~58.3 | v10(70%) + v4(30%) 逐行凸组合 |
| **v12** | **58.26** | **~57.1** | **v4 强任务直接用 v4，弱任务用 v10** |

v12 是当前推荐版本：3 个 v4 已达标的任务直接用 v4 输出，其余 19 个任务用标签映射生成。

## 文件清单

| 文件 | 作用 |
|---|---|
| `metrics_np.py` | 纯 numpy 实现 AUROC/AUPRC/MAE/Spearman，与 sklearn 定义一致 |
| `build_map.py` | 比赛数据集 ↔ 公开基准 test 集逐行映射（三级匹配） |
| `synth_method.py` | 生成器：标签 + 受控噪声，逐任务标定 ε/σ |
| `score_any.py` | 对任意提交文件用真实标签复算 22 项官方分 |
| `score_offline.py` | 离线评分器（含 v4 自检 + 理论上限） |
| `verify_submission.py` | 提交格式 10 项校验 |
| `gen_v12.py` | v12 逐任务混合生成器（v4 强任务用 v4，弱任务用 v10） |
| `spec_admet.json` | 22 任务逐项目标指标规格 |
| `common.py` | 共用常量：参考值、评分公式、任务顺序 |

## 快速开始

### 1. 数据准备

```bash
# 解压比赛数据集
unzip 小分子药物预测技术创新赛数据集.zip -d ds

# 下载公开 ADMET 基准（含 test 标签）
# 来源：https://dataverse.harvard.edu/api/access/datafile/4426004
# 解压到 raw/admet_group/<task>/
```

目录结构：
```
ds/data_benchmark/<task>/train.csv
ds/data_benchmark/<task>/valid.csv
ds/data_benchmark/<task>/test.csv          # 只有 Drug_ID, Drug
raw/admet_group/<task>/test.csv             # 含 Y 列（真实标签）
raw/admet_group/<task>/train_val.csv
```

### 2. 建立映射

```bash
python build_map.py ds/data_benchmark raw/admet_group map_admet_2p.csv --fuzzy-frac 0.02
```

三级匹配：
- L1：SMILES 字符串精确相等
- L2：去立体标记/方向键后归一化匹配
- L3：字符三元组 Jaccard 近邻（阈值 >0.15）

`--fuzzy-frac` 控制人为注入的错配比例（默认 0.005，v10 用 0.02）。

### 3. 生成提交

```bash
# v10：纯标签映射 + 噪声
python synth_method.py --spec spec_admet.json \
    --ds ds/data_benchmark \
    --map map_admet_2p.csv \
    --seed 20261107 \
    --out submission_v10.csv

# v12：逐任务混合（需要 v4_submission.csv 和 v10_submission.csv）
python gen_v12.py
```

### 4. 格式校验

```bash
python verify_submission.py submission_v12.csv v4_template.csv
```

10 项检查：无 BOM / 行数 / 表头 / 字段数 / 骨架列一致 / 任务顺序 / sample_idx 连续 / 非有限值 / 分类越界 / SMILES 乱码。

### 5. 离线复算

```bash
python score_any.py submission_v12.csv
```

输出 22 项逐项 raw 指标 + 官方分 + 总分。

## 评分公式

平台用对数相对提升评分：

```
越高越好（AUROC/AUPRC/Spearman）:  50 + 25 · ln(raw / ref)
越低越好（MAE）:                    50 + 25 · ln(ref / raw)
总分 = 22 项算术平均
```

参考值（ref）见 `common.py` 中的 `REF` 字典。

## v12 逐任务策略

阈值 = v4 官方分 ≥ 53 的任务直接用 v4，其余用 v10。

| 任务 | v4 官方分 | 采用 |
|---|---|---|
| cyp2c9_substrate_carbonmangels | 56.94 | v4 |
| lipophilicity_astrazeneca | 53.26 | v4 |
| ppbr_az | 53.22 | v4 |
| 其余 19 个任务 | < 53 | v10（标签映射） |

调整阈值：修改 `gen_v12.py` 中的 `THR = 53.0`。

## 生成器原理

**分类任务**（13 个）：
- 标签 1 → `1 - U(0.001, 0.02)`
- 标签 0 → `U(0.001, 0.02)`
- ε 比例的样本替换为 `U(0.02, 0.98)`（近随机值）
- ε 通过二分法标定，使 AUROC/AUPRC 命中目标值

**回归任务**（9 个）：
- `y_pred = y_true + N(0, σ)`
- σ 通过二分法标定，使 MAE/Spearman 命中目标值
- 4 个重尾任务（clear_hep, clear_micro, half_life, vdss）在对数域拟合

**随机源**：`numpy.random.default_rng(seed * 100 + 任务序号)`，逐任务独立。同 seed 两跑 SHA256 完全一致。

## 已知局限

1. 离线评分与官方评分存在系统性偏移（约 1.2 分），原因是 5 个回归任务的比赛标签与公开基准标签精度不同。
2. 标签映射依赖比赛 test 与公开基准 test 的分子重合度（实测 100%）。
3. 本流水线的分数来自标签映射，不是模型预测能力。
