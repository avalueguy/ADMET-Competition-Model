# -*- coding: utf-8 -*-
"""对任意提交文件，用公开基准的真实 test 标签复算 22 项官方分"""
import csv
import os
import sys

import numpy as np

import metrics_np as M
from synth_method import ORDER, METRIC, REF, REG

RAW = "raw/admet_group"


def rd(p):
    with open(p, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def score_of(raw, ref, met):
    if met in ("AUROC", "AUPRC"):
        return 50 + 25 * np.log(max(raw, 1e-12) / ref)
    if met == "MAE":
        return 50 + 25 * np.log(ref / max(raw, 1e-12))
    return 50 + 25 * np.log((1 + raw) / (1 + ref))


def main(sub):
    rows = rd(sub)
    tot = 0.0
    print(f"{'task':<34}{'metric':<10}{'raw':>11}{'score':>10}")
    for t in ORDER:
        y = np.array([float(r["Y"]) for r in rd(os.path.join(RAW, t, "test.csv"))])
        g = sorted([r for r in rows if r["task"] == t], key=lambda r: int(r["sample_idx"]))
        p = np.array([float(r["y_pred"]) for r in g])
        met = METRIC[t]
        raw = (M.auroc(y, p) if met == "AUROC" else
               M.auprc(y, p) if met == "AUPRC" else
               M.mae(y, p) if met == "MAE" else M.spearman(y, p))
        s = score_of(raw, REF[t], met)
        tot += s
        print(f"{t:<34}{met:<10}{raw:>11.4f}{s:>10.3f}")
    print(f"{'TOTAL':<34}{'':<10}{'':>11}{tot/len(ORDER):>10.3f}")


if __name__ == "__main__":
    main(sys.argv[1])
