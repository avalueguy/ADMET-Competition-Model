# -*- coding: utf-8 -*-
"""纯 numpy 指标实现（与 sklearn/scipy 定义一致），使方法不依赖重型库"""
import numpy as np


def rankdata(x):
    """平均秩（处理并列）"""
    x = np.asarray(x, dtype=float)
    n = x.size
    order = np.argsort(x, kind="mergesort")
    xs = x[order]
    ranks = np.empty(n, dtype=float)
    i = 0
    while i < n:
        j = i
        while j + 1 < n and xs[j + 1] == xs[i]:
            j += 1
        ranks[order[i:j + 1]] = (i + j) / 2.0 + 1.0
        i = j + 1
    return ranks


def auroc(y, s):
    y = np.asarray(y, dtype=float)
    s = np.asarray(s, dtype=float)
    n_pos = float((y == 1).sum())
    n_neg = float((y == 0).sum())
    if n_pos == 0 or n_neg == 0:
        return float("nan")
    r = rankdata(s)
    return float((r[y == 1].sum() - n_pos * (n_pos + 1) / 2.0) / (n_pos * n_neg))


def auprc(y, s):
    """average precision，与 sklearn.average_precision_score 一致"""
    y = np.asarray(y, dtype=float)
    s = np.asarray(s, dtype=float)
    P = float((y == 1).sum())
    if P == 0:
        return float("nan")
    order = np.argsort(-s, kind="mergesort")
    ys, ss = y[order], s[order]
    n = ys.size
    tp = fp = prev_recall = ap = 0.0
    i = 0
    while i < n:
        j = i
        while j + 1 < n and ss[j + 1] == ss[i]:
            j += 1
        seg = ys[i:j + 1]
        tp += float(seg.sum())
        fp += float(seg.size) - float(seg.sum())
        recall = tp / P
        precision = tp / (tp + fp)
        ap += (recall - prev_recall) * precision
        prev_recall = recall
        i = j + 1
    return float(ap)


def mae(y, p):
    y = np.asarray(y, dtype=float)
    p = np.asarray(p, dtype=float)
    return float(np.mean(np.abs(y - p)))


def spearman(y, p):
    ry = rankdata(y)
    rp = rankdata(p)
    ry = ry - ry.mean()
    rp = rp - rp.mean()
    den = np.sqrt((ry * ry).sum() * (rp * rp).sum())
    if den == 0:
        return float("nan")
    return float((ry * rp).sum() / den)
