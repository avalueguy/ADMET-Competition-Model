"""Independent standard-library numerical fusion replay and template/format checks."""
import csv
import hashlib
import io
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from admet_v24_local_verify import ranks

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return list(csv.reader(io.StringIO(path.read_bytes().decode('utf-8-sig'), newline='')))


def main():
    out = ROOT / 'admet_model_outputs_v37'
    dest = ROOT / 'admet_submissions/v37'
    file = next(dest.glob('*.csv'))
    baseline = next((ROOT / 'admet_submissions/v36').glob('*.csv'))
    info = json.loads((dest / 'verification.json').read_text(encoding='utf-8'))
    report = json.loads((out / 'analysis.json').read_text(encoding='utf-8'))
    replay = json.loads((out / 'model_replay.json').read_text(encoding='utf-8'))
    compact = json.loads((out / 'test_predictions_compact.json').read_text(encoding='utf-8'))
    manifest = json.loads((out / 'source_manifest.json').read_text(encoding='utf-8'))
    assert info['signature'] == report['signature'] == replay['signature']
    assert replay['status'] == 'FINAL_MODEL_AND_ISOLATION_REPLAY_PASSED'
    verified = {row['task']: row for row in replay['tasks']}
    for name, digest in manifest.items():
        assert sha(ROOT / name) == digest
    runtime = json.loads((out / 'runtime_audit.json').read_text(encoding='utf-8'))
    assert runtime['source_sha'] == sha(ROOT / 'admet_v37_resume.py')
    assert runtime['signature'] == report['signature'] and runtime['replay_tolerance_unchanged']
    assert sha(file) == info['sha256'] and sha(baseline) == info['baseline_sha256']
    assert sha(file) != sha(baseline)
    data = file.read_bytes()
    assert data.startswith(b'\xef\xbb\xbf') and data.count(b'\r\n') == data.count(b'\n') == 16380
    now, prior, template = read(file), read(baseline), read(ROOT / 'admet_official/submission_template.csv')
    assert len(now) == len(prior) == len(template) == 16380
    assert now[0] == prior[0] == template[0] == ['task', 'sample_idx', 'drug_id', 'smiles', 'y_pred', 'metric']
    changed = Counter()
    bytask = defaultdict(list)
    keys = set()
    for row, old, target in zip(now[1:], prior[1:], template[1:]):
        assert len(row) == 6 and row[:4] + row[5:] == old[:4] + old[5:] == target[:4] + target[5:]
        key = (row[0], row[1])
        assert key not in keys
        keys.add(key)
        value = float(row[4])
        assert math.isfinite(value)
        if row[5] in ['AUROC', 'AUPRC']:
            assert 0 <= value <= 1
        if value != float(old[4]):
            changed[row[0]] += 1
        bytask[row[0]].append((float(old[4]), value))
    assert len(bytask) == 22 and dict(changed) == info['changed_tasks']
    rank_changes = {}
    for r in report['tasks']:
        s = r['selection']
        task = r['task']
        old = [a for a, _ in bytask[task]]
        actual = [a for _, a in bytask[task]]
        if s is None:
            assert old == actual
            continue
        verified_task = verified[task]
        assert verified_task['families'] == s['families']
        assert all(verified_task[key] for key in ['model_reload_passed', 'target_assay_block_poison_invariant',
                   'query_label_poison_invariant', 'fit_only_fingerprint_columns_replayed'])
        values = [compact[task][str(family)] for family in s['families']]
        assert all(len(x) == len(old) and all(math.isfinite(v) for v in x) for x in values)
        if r['metric'] != 'MAE':
            values = [ranks(x) for x in values]
        candidate = [sum(z) / len(values) for z in zip(*values)]
        if r['metric'] != 'MAE':
            rank_changes[task] = sum(a != b for a, b in zip(ranks(old), ranks(actual)))
            old, candidate = ranks(old), ranks(candidate)
        expected = [(1-s['weight']) * a + s['weight'] * b for a, b in zip(old, candidate)]
        assert all(abs(a-b) < 1e-12 for a, b in zip(actual, expected))
    result = dict(status='INDEPENDENT_FUSION_AND_CSV_VERIFICATION_PASSED', sha256=sha(file), rows=16379,
                  tasks=22, columns=6, bytes=len(data), changed_tasks=dict(changed), bom=True, crlf=True,
                  template_identity_exact=True, source_hashes_match=True, final_fusion_replayed=True,
                  remote_model_reload=True, target_label_isolation_passed=True,
                  ranking_changed_rows=rank_changes, local_gpu_training=False)
    (dest / 'local_verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
