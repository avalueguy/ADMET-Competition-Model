# -*- coding: utf-8 -*-
"""
D-MPNN (Chemprop 风格) + RDKit 描述符
- 骨架切分 CV（与 GBM 共用同一套折，便于公平融合）
- 早停 + 多 seed 平均
"""
import os, sys, json, time, argparse, warnings
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.preprocessing import StandardScaler
from pathlib import Path

from rdkit import Chem, RDLogger
RDLogger.DisableLog("rdApp.*")

from common import (REF, METRIC, LOG_TARGET, score_metric, comp_score,
                    load_task, scaffold_folds, FEAT, ROOT)

OUT = ROOT / "runs" / "gnn"
OUT.mkdir(parents=True, exist_ok=True)

ALLOWED_NUM = [1, 5, 6, 7, 8, 9, 11, 12, 14, 15, 16, 17, 19, 20, 26, 29, 30, 33,
               34, 35, 38, 42, 51, 53, 55, 56, 80, 82]
NUM_IDX = {z: i for i, z in enumerate(ALLOWED_NUM)}
ATOM_DIM = len(ALLOWED_NUM) + 1 + 6 + 5 + 5 + 6 + 1 + 1 + 1
BOND_DIM = 4 + 1 + 1 + 6
BT = {Chem.BondType.SINGLE: 0, Chem.BondType.DOUBLE: 1, Chem.BondType.TRIPLE: 2,
      Chem.BondType.AROMATIC: 3}


def atom_feats(a):
    f = np.zeros(ATOM_DIM, dtype=np.float32)
    i = NUM_IDX.get(a.GetAtomicNum(), len(ALLOWED_NUM))
    f[i] = 1.0
    o = len(ALLOWED_NUM) + 1
    f[o + min(a.GetTotalDegree(), 5)] = 1.0; o += 6
    f[o + min(max(a.GetFormalCharge(), -2), 2) + 2] = 1.0; o += 5
    f[o + min(a.GetTotalNumHs(), 4)] = 1.0; o += 5
    hidx = {"SP": 0, "SP2": 1, "SP3": 2, "SP3D": 3, "SP3D2": 4}.get(str(a.GetHybridization()), 5)
    f[o + hidx] = 1.0; o += 6
    f[o] = 1.0 if a.GetIsAromatic() else 0.0; o += 1
    f[o] = 1.0 if a.IsInRing() else 0.0; o += 1
    f[o] = a.GetMass() * 0.01
    return f


def bond_feats(b):
    f = np.zeros(BOND_DIM, dtype=np.float32)
    f[BT.get(b.GetBondType(), 0)] = 1.0
    f[4] = 1.0 if b.GetIsConjugated() else 0.0
    f[5] = 1.0 if b.IsInRing() else 0.0
    sidx = {"STEREONONE": 0, "STEREOANY": 1, "STEREOZ": 2, "STEREOE": 3,
            "STEREOCIS": 4, "STEREOTRANS": 5}.get(str(b.GetStereo()), 0)
    f[6 + sidx] = 1.0
    return f


def mol_to_graph(smi):
    mol = Chem.MolFromSmiles(smi)
    if mol is None or mol.GetNumAtoms() == 0:
        return None
    af = np.stack([atom_feats(a) for a in mol.GetAtoms()])
    bfs, src, dst = [], [], []
    for b in mol.GetBonds():
        i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
        f = bond_feats(b)
        bfs.append(f); src.append(i); dst.append(j)
        bfs.append(f); src.append(j); dst.append(i)
    if bfs:
        bf = np.stack(bfs); e = np.stack([src, dst], 1).astype(np.int64)
    else:
        bf = np.zeros((0, BOND_DIM), np.float32); e = np.zeros((0, 2), np.int64)
    return af, bf, e


def make_batch(graphs, descs, idxs, device):
    A, B, E, MO = [], [], [], []
    off = 0
    for k, i in enumerate(idxs):
        g = graphs[i]
        if g is None:
            af = np.zeros((1, ATOM_DIM), np.float32)
            bf = np.zeros((0, BOND_DIM), np.float32)
            ee = np.zeros((0, 2), np.int64)
        else:
            af, bf, ee = g
        A.append(af); B.append(bf); E.append(ee + off)
        MO.append(np.full(len(af), k, np.int64))
        off += len(af)
    atom = torch.from_numpy(np.concatenate(A)).to(device)
    bond = torch.from_numpy(np.concatenate(B)).to(device)
    e = torch.from_numpy(np.concatenate(E)).to(device)
    molof = torch.from_numpy(np.concatenate(MO)).to(device)
    d = torch.from_numpy(np.asarray(descs, np.float32)).to(device)
    return atom, bond, e, molof, d, len(idxs)


class Enc(nn.Module):
    def __init__(self, adim, bdim, hidden=200, depth=3, dropout=0.15):
        super().__init__()
        self.Wi = nn.Linear(adim, hidden)
        self.Wb = nn.Linear(bdim, hidden, bias=False)
        self.Wm = nn.Linear(hidden, hidden, bias=False)
        self.Wo = nn.Linear(bdim, hidden, bias=False)
        self.Wm2 = nn.Linear(hidden, hidden, bias=False)
        self.Wp = nn.Linear(hidden, hidden)
        self.depth = depth
        self.drop = nn.Dropout(dropout)

    def forward(self, atom, bond, e, molof, n):
        h0 = F.relu(self.Wi(atom))
        m = self.Wb(bond)
        for _ in range(self.depth):
            M = torch.zeros(h0.size(0), h0.size(1), device=h0.device, dtype=h0.dtype)
            M.index_add_(0, e[:, 1], m)
            h = F.relu(h0 + self.Wm(M))
            m = self.drop(F.relu(h[e[:, 0]] + self.Wo(bond)))
        M = torch.zeros_like(h0)
        M.index_add_(0, e[:, 1], m)
        hf = F.relu(h0 + self.Wm2(M))
        p = F.relu(self.Wp(hf))
        z = torch.zeros(n, p.size(1), device=p.device, dtype=p.dtype)
        z.index_add_(0, molof, p)
        return z


class Net(nn.Module):
    def __init__(self, adim, bdim, n_desc, hidden=200, depth=3, dropout=0.15, ffn_h=400):
        super().__init__()
        self.enc = Enc(adim, bdim, hidden, depth, dropout)
        self.ffn = nn.Sequential(
            nn.Linear(hidden + n_desc, ffn_h), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(ffn_h, ffn_h), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(ffn_h, 1))

    def forward(self, atom, bond, e, molof, desc, n):
        return self.ffn(torch.cat([self.enc(atom, bond, e, molof, n), desc], 1)).squeeze(1)


def better(a, b, metric):
    if b is None or not np.isfinite(b):
        return True
    if not np.isfinite(a):
        return False
    return (a < b) if metric == "MAE" else (a > b)


def run(task, blocks, idx_of, folds_n, seeds, max_epochs, device, bs, tag=""):
    t0 = time.time()
    metric = METRIC[task]
    kind = "cls" if metric in ("AUROC", "AUPRC") else "reg"
    use_log = task in LOG_TARGET
    tr, va, te = load_task(task)
    sm_tr = tr["Drug"].astype(str).tolist(); sm_va = va["Drug"].astype(str).tolist()
    sm_te = te["Drug"].astype(str).tolist()
    smiles = sm_tr + sm_va
    y_raw = np.concatenate([tr["Y"].values.astype(float), va["Y"].values.astype(float)])
    y = np.log1p(y_raw) if use_log else y_raw

    gcache = {}
    def G(s):
        if s not in gcache:
            gcache[s] = mol_to_graph(s)
        return gcache[s]
    graphs_ref = [G(s) for s in smiles]
    graphs_te = [G(s) for s in sm_te]

    desc_all = np.nan_to_num(blocks["desc"][np.array([idx_of[s] for s in smiles])],
                             nan=0.0, posinf=0.0, neginf=0.0)
    desc_te = np.nan_to_num(blocks["desc"][np.array([idx_of[s] for s in sm_te])],
                            nan=0.0, posinf=0.0, neginf=0.0)
    n = len(y)
    folds, scheme = scaffold_folds(smiles, y, folds_n, seed=7, kind=kind)

    adim, bdim, ndesc = ATOM_DIM, BOND_DIM, desc_all.shape[1]
    oof = np.zeros(n)
    best_eps = []

    for fi, (itr, iva) in enumerate(folds):
        sc = StandardScaler().fit(desc_all[itr])
        Dtr = sc.transform(desc_all[itr]).astype(np.float32)
        Dva = sc.transform(desc_all[iva]).astype(np.float32)
        ytr = y[itr]
        if kind == "reg":
            ym, ys = ytr.mean(), ytr.std() + 1e-6
            tgt = (ytr - ym) / ys
        else:
            tgt = ytr
        seed_preds, seed_eps = [], []
        for sd in range(seeds):
            torch.manual_seed(1000 * sd + fi); np.random.seed(1000 * sd + fi)
            model = Net(adim, bdim, ndesc).to(device)
            opt = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-5)
            nb = int(np.ceil(len(itr) / bs))
            sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=1e-3,
                                                        total_steps=max_epochs * nb)
            if kind == "cls":
                pos = max(tgt.sum(), 1.0); neg = len(tgt) - pos
                pw = torch.tensor([neg / pos], device=device, dtype=torch.float32)
                lossfn = nn.BCEWithLogitsLoss(pos_weight=pw)
            else:
                lossfn = nn.SmoothL1Loss(beta=0.1) if metric == "MAE" else nn.MSELoss()
            gi_va = [int(k) for k in iva]
            best_m, best_p, best_ep, bad = None, None, max_epochs, 0
            for ep in range(max_epochs):
                model.train()
                perm = np.random.permutation(len(itr))
                for b0 in range(0, len(itr), bs):
                    bidx = perm[b0:b0 + bs]
                    gi = [int(itr[k]) for k in bidx]
                    atom, bond, e, molof, d, nb_ = make_batch(graphs_ref, Dtr[bidx], gi, device)
                    out = model(atom, bond, e, molof, d, nb_)
                    t = torch.tensor(tgt[bidx], dtype=torch.float32, device=device)
                    loss = lossfn(out, t)
                    opt.zero_grad(); loss.backward()
                    nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                    opt.step()
                    try:
                        sched.step()
                    except Exception:
                        pass
                if ep >= 10:
                    model.eval()
                    with torch.no_grad():
                        atom, bond, e, molof, d, nb2 = make_batch(graphs_ref, Dva, gi_va, device)
                        p = model(atom, bond, e, molof, d, nb2).cpu().numpy()
                    if kind == "reg":
                        p = p * ys + ym
                    m = score_metric(y[iva], p, metric)
                    if better(m, best_m, metric):
                        best_m, best_p, best_ep, bad = m, p, ep + 1, 0
                    else:
                        bad += 1
                        if bad >= 25:
                            break
            seed_preds.append(best_p); seed_eps.append(best_ep)
        oof[iva] = np.mean(seed_preds, 0)
        best_eps.extend(seed_eps)

    oof_m = score_metric(y, oof, metric)
    E = max(15, int(np.median(best_eps)))

    sc = StandardScaler().fit(desc_all)
    Dall = sc.transform(desc_all).astype(np.float32)
    Dte = sc.transform(desc_te).astype(np.float32)
    if kind == "reg":
        ym, ys = y.mean(), y.std() + 1e-6
        tgt = (y - ym) / ys
    else:
        tgt = y
    allpred = np.zeros(len(sm_te))
    for sd in range(seeds):
        torch.manual_seed(2000 + sd); np.random.seed(2000 + sd)
        model = Net(adim, bdim, ndesc).to(device)
        opt = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-5)
        nb = int(np.ceil(n / bs))
        sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=1e-3, total_steps=E * nb)
        if kind == "cls":
            pos = max(tgt.sum(), 1.0); neg = len(tgt) - pos
            pw = torch.tensor([neg / pos], device=device, dtype=torch.float32)
            lossfn = nn.BCEWithLogitsLoss(pos_weight=pw)
        else:
            lossfn = nn.SmoothL1Loss(beta=0.1) if metric == "MAE" else nn.MSELoss()
        snaps = []
        for ep in range(E):
            model.train()
            perm = np.random.permutation(n)
            for b0 in range(0, n, bs):
                bidx = perm[b0:b0 + bs]
                gi = [int(k) for k in bidx]
                atom, bond, e, molof, d, nb2 = make_batch(graphs_ref, Dall[bidx], gi, device)
                out = model(atom, bond, e, molof, d, nb2)
                t = torch.tensor(tgt[bidx], dtype=torch.float32, device=device)
                loss = lossfn(out, t)
                opt.zero_grad(); loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                opt.step()
                try:
                    sched.step()
                except Exception:
                    pass
            if ep >= E - 5:
                model.eval()
                with torch.no_grad():
                    gi = list(range(len(sm_te)))
                    atom, bond, e, molof, d, nb2 = make_batch(graphs_te, Dte, gi, device)
                    snaps.append(model(atom, bond, e, molof, d, nb2).cpu().numpy())
        p = np.mean(snaps, 0)
        if kind == "reg":
            p = p * ys + ym
        allpred += p / seeds
    if use_log:
        allpred = np.expm1(allpred)

    res = dict(task=task, metric=metric, kind=kind, n=int(n), n_test=len(sm_te),
               oof=float(oof_m), ref=REF[task], cv=scheme, E=int(E),
               comp=float(comp_score(oof_m, metric, REF[task])),
               seconds=round(time.time() - t0, 1))
    np.savez_compressed(OUT / f"{task}_gnn.npz", test=allpred, oof=oof, y=y)
    print(f"[gnn] {task:<36} {metric:<9} OOF={oof_m:.4f} ref={REF[task]:.4f} "
          f"score={res['comp']:.2f} E={E} {scheme} {res['seconds']}s", flush=True)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", nargs="*", default=None)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--epochs", type=int, default=150)
    ap.add_argument("--bs", type=int, default=64)
    a = ap.parse_args()
    tasks = a.tasks or sorted(METRIC)
    blocks = dict(np.load(FEAT / "feats.npz"))
    smiles_all = np.load(FEAT / "smiles.npy", allow_pickle=True)
    idx_of = {s: i for i, s in enumerate(smiles_all.tolist())}
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[info] device={device} tasks={len(tasks)}", flush=True)
    results = []
    rf = OUT / "results_gnn.json"
    if rf.exists():
        try:
            results = json.load(open(rf))
        except Exception:
            results = []
    done = {r["task"] for r in results if "comp" in r}
    for t in tasks:
        if t in done:
            print(f"[skip] {t} already done", flush=True); continue
        try:
            r = run(t, blocks, idx_of, a.folds, a.seeds, a.epochs, device, a.bs)
        except Exception as e:
            import traceback; traceback.print_exc()
            r = dict(task=t, error=str(e))
        results = [x for x in results if x.get("task") != t] + [r]
        json.dump(results, open(rf, "w"), indent=2, ensure_ascii=False)
    ok = [r for r in results if "comp" in r]
    if ok:
        print(f"\n[summary] {len(ok)} 项平均 = {np.mean([r['comp'] for r in ok]):.4f}", flush=True)


if __name__ == "__main__":
    main()
