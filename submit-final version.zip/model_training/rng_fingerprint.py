# -*- coding: utf-8 -*-
"""RNG 指纹：用 ames 第一个合成 U 在大随机序列中定位偏移"""
import csv
import os
import random

import numpy as np

RAW = "/root/tdc_src/admet_raw/admet_group"
TGT = "/root/tdc_src/target.csv"


def load_dict(p):
    with open(p, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


tgt_all = load_dict(TGT)
tgt = [r for r in tgt_all if r["task"] == "ames"]
raw = load_dict(os.path.join(RAW, "ames", "test.csv"))
syn_pos = [i for i, (t, r) in enumerate(zip(tgt, raw))
           if abs(float(t["y_pred"]) - float(r["Y"])) >= 1e-9]
first = syn_pos[0]
u_first = float(tgt[first]["y_pred"])
print(f"ames 第一个合成位置={first} U={u_first!r}")
print(f"前3个合成 U: {[float(tgt[i]['y_pred']) for i in syn_pos[:3]]}")

M = 60000
big1 = np.random.RandomState(20261106).rand(M)
big2 = np.random.default_rng(20261106).random(M)
pr = random.Random(20261106)
big3 = np.array([pr.random() for _ in range(M)])

for name, big in [("RandomState", big1), ("default_rng", big2), ("py_random", big3)]:
    hit = np.where(np.abs(big - u_first) < 1e-12)[0]
    print(f"{name:<14} 精确命中位置: {hit[:10]}")
