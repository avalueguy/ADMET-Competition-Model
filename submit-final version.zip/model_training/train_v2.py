# -*- coding: utf-8 -*-
"""
ADMET 全新建模流水线（v2）
- 特征：RDKit 描述符 + Morgan(r2/r3) + MACCS + Avalon
- 基模型：LightGBM / CatBoost / XGBoost / ExtraTrees / Ridge / Tanimoto-kNN
- 5 折 CV 产生 OOF -> Caruana 贪心集成选权
- 另做「train -> valid」诚实评估
- 最终 train+valid 重训 -> 预测 test -> 生成提交文件
"""
import os, sys, json, time, pickle, warnings
import numpy as np
import pandas as pd
from pathlib import Path
import scipy.sparse as sp
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score, average_precision_score
from sklearn.model_selection import StratifiedKFold, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import ExtraTreesClassifier, ExtraTreesRegressor
from sklearn.linear_model import Ridge
warnings.filterwarnings("ignore")

import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier, CatBoostRegressor

ROOT = Path("/root/autodl-tmp/admet2")
DATA = ROOT / "data_benchmark"
FEAT = ROOT / "features"
OUT = ROOT / "runs" / "v2"
OUT.mkdir(parents=True, exist_ok=True)

NFOLD = 5
KNN_K = 8
SEED = 20261106
ENS_STEPS = 20

# 参考值（赛事公布），顺序与 upload_template 的任务顺序一致
REF = {
    "ames": 0.871945, "bbb_martins": 0.927779, "bioavailability_ma": 0.722248,
    "caco2_wang": 0.283647, "clearance_hepatocyte_az": 0.55204,
    "clearance_microsome_az": 0.642814, "cyp2c9_substrate_carbonmangels": 0.44337,
    "cyp2c9_veith": 0.790586, "cyp2d6_substrate_carbonmangels": 0.747531,
    "cyp2d6_veith": 0.719172, "cyp3a4_substrate_carbonmangels": 0.725249,
    "cyp3a4_veith": 0.884121, "dili": 0.908609, "half_life_obach": 0.49139,
    "herg": 0.863358, "hia_hou": 0.99428, "ld50_zhu": 0.603071,
    "lipophilicity_astrazeneca": 0.472895, "pgp_broccatelli": 0.938363,
    "ppbr_az": 7.330617, "solubility_aqsoldb": 0.738443, "vdss_lombardo": 0.660995,
}
METRIC = {
    "ames": "AUROC", "bbb_martins": "AUROC", "bioavailability_ma": "AUROC",
    "caco2_wang": "MAE", "clearance_hepatocyte_az": "Spearman",
    "clearance_microsome_az": "Spearman", "cyp2c9_substrate_carbonmangels": "AUPRC",
    "cyp2c9_veith": "AUPRC", "cyp2d6_substrate_carbonmangels": "AUPRC",
    "cyp2d6_veith": "AUPRC", "cyp3a4_substrate_carbonmangels": "AUROC",
    "cyp3a4_veith": "AUPRC", "dili": "AUROC", "half_life_obach": "Spearman",
    "herg": "AUROC", "hia_hou": "AUROC", "ld50_zhu": "MAE",
    "lipophilicity_astrazeneca": "MAE", "pgp_broccatelli": "AUROC",
    "ppbr_az": "MAE", "solubility_aqsoldb": "MAE", "vdss_lombardo": "Spearman",
}
# 偏态回归：对数变换（仅对 Spearman 任务，单调不变）
LOG_TARGET = {"clearance_hepatocyte_az", "clearance_microsome_az",
              "half_life_obach", "vdss_lombardo"}


# ---------------- 指标 ----------------
def score_metric(y, p, metric):
    y = np.asarray(y, float); p = np.asarray(p, float)
    if metric in ("AUROC", "AUPRC"):
        if len(np.unique(y)) < 2:
            return float("nan")
        return roc_auc_score(y, p) if metric == "AUROC" else average_precision_score(y, p)
    if metric == "Spearman":
        r = spearmanr(y, p).correlation
        return float(r) if np.isfinite(r) else float("nan")
    return float(np.mean(np.abs(y - p)))


def comp_score(raw, metric, ref):
    """赛事评分：50 + 25*ln(比值)"""
    if metric == "MAE":
        return 50.0 + 25.0 * np.log(ref / max(raw, 1e-9))
    if metric == "Spearman":
        return 50.0 + 25.0 * np.log((1.0 + raw) / (1.0 + ref))
    return 50.0 + 25.0 * np.log(max(raw, 1e-9) / ref)


# ---------------- 数据 ----------------
def load_task(task):
    def rd(part):
        df = pd.read_csv(DATA / task / f"{part}.csv")
        df.columns = [c.strip().strip('"') for c in df.columns]
        return df
    tr, va, te = rd("train"), rd("valid"), rd("test")
    return tr, va, te


def feats_for(smiles, blocks, idx_of):
    rows = np.array([idx_of[s] for s in smiles], dtype=np.int64)
    parts = []
    d = blocks["desc"][rows]
    parts.append(np.nan_to_num(d, nan=0.0, posinf=0.0, neginf=0.0).astype(np.float32))
    for k in ("morgan2", "morgan3", "maccs", "avalon"):
        parts.append(blocks[k][rows].astype(np.float32))
    return np.hstack(parts)


# ---------------- 基模型 ----------------
def fit_lgb(Xtr, ytr, Xte, kind, metric):
    if kind == "cls":
        m = lgb.LGBMClassifier(n_estimators=900, learning_rate=0.03, num_leaves=31,
                               min_child_samples=15, colsample_bytree=0.25,
                               subsample=0.8, subsample_freq=1, reg_lambda=5.0,
                               n_jobs=4, random_state=SEED, verbose=-1)
    else:
        obj = "l1" if metric == "MAE" else "l2"
        m = lgb.LGBMRegressor(n_estimators=1200, learning_rate=0.03, num_leaves=31,
                              min_child_samples=10, colsample_bytree=0.25,
                              subsample=0.8, subsample_freq=1, reg_lambda=3.0,
                              objective=obj, n_jobs=4, random_state=SEED, verbose=-1)
    m.fit(Xtr, ytr)
    return m.predict_proba(Xte)[:, 1] if kind == "cls" else m.predict(Xte)


def fit_xgb(Xtr, ytr, Xte, kind, metric):
    if kind == "cls":
        m = xgb.XGBClassifier(n_estimators=900, learning_rate=0.03, max_depth=6,
                              subsample=0.8, colsample_bytree=0.25,
                              min_child_weight=3, reg_lambda=2.0, tree_method="hist",
                              n_jobs=4, random_state=SEED, eval_metric="logloss")
        m.fit(Xtr, ytr)
        return m.predict_proba(Xte)[:, 1]
    obj = "reg:absoluteerror" if metric == "MAE" else "reg:squarederror"
    m = xgb.XGBRegressor(n_estimators=1000, learning_rate=0.03, max_depth=6,
                         subsample=0.8, colsample_bytree=0.25,
                         min_child_weight=3, reg_lambda=2.0, tree_method="hist",
                         objective=obj, n_jobs=4, random_state=SEED)
    m.fit(Xtr, ytr)
    return m.predict(Xte)


def fit_cat(Xtr, ytr, Xte, kind, metric):
    if kind == "cls":
        m = CatBoostClassifier(iterations=1200, learning_rate=0.03, depth=6, rsm=0.3,
                               l2_leaf_reg=10, random_seed=SEED, verbose=0,
                               thread_count=4, allow_writing_files=False)
        m.fit(Xtr, ytr)
        return m.predict_proba(Xte)[:, 1]
    loss = "MAE" if metric == "MAE" else "RMSE"
    m = CatBoostRegressor(iterations=1400, learning_rate=0.03, depth=6, rsm=0.3,
                          l2_leaf_reg=10, loss_function=loss, random_seed=SEED,
                          verbose=0, thread_count=4, allow_writing_files=False)
    m.fit(Xtr, ytr)
    return m.predict(Xte)


def fit_et(Xtr, ytr, Xte, kind, metric):
    if kind == "cls":
        m = ExtraTreesClassifier(n_estimators=500, max_features="sqrt",
                                 min_samples_leaf=2, n_jobs=4, random_state=SEED)
        m.fit(Xtr, ytr)
        return m.predict_proba(Xte)[:, 1]
    m = ExtraTreesRegressor(n_estimators=500, max_features="sqrt",
                            min_samples_leaf=2, n_jobs=4, random_state=SEED)
    m.fit(Xtr, ytr)
    return m.predict(Xte)


def fit_ridge(Xtr, ytr, Xte, kind, metric):
    if kind == "cls":
        from sklearn.linear_model import LogisticRegression
        sc = StandardScaler().fit(Xtr)
        m = LogisticRegression(C=1.0, max_iter=2000)
        m.fit(sc.transform(Xtr), ytr)
        return m.predict_proba(sc.transform(Xte))[:, 1]
    sc = StandardScaler().fit(Xtr)
    m = Ridge(alpha=2.0)
    m.fit(sc.transform(Xtr), ytr)
    return m.predict(sc.transform(Xte))


def fit_knn(S_tr, ytr, S_te_mat, kind, k=KNN_K):
    """Tanimoto kNN：S_tr 为 train 的 morgan2 二值矩阵"""
    def tanimoto(A, B):
        a = A.sum(1); b = B.sum(1)
        inter = A @ B.T
        return inter / np.maximum(a[:, None] + b[None, :] - inter, 1e-9)
    sim = tanimoto(S_te_mat, S_tr) if S_te_mat.shape[0] > 0 else None
    k = min(k, S_tr.shape[0])
    idx = np.argpartition(-sim, k - 1, axis=1)[:, :k]
    w = np.take_along_axis(sim, idx, axis=1)
    w = np.maximum(w, 0.0)
    if kind == "cls":
        yv = ytr[idx]
        return (w * yv).sum(1) / np.maximum(w.sum(1), 1e-9)
    return (w * ytr[idx]).sum(1) / np.maximum(w.sum(1), 1e-9)


BASE = [("lgb", fit_lgb), ("xgb", fit_xgb), ("cat", fit_cat),
        ("et", fit_et), ("ridge", fit_ridge)]

N_DESC = None  # 运行时由 feats 决定


def des_only(X):
    return X[:, :N_DESC]


def run_task(task, blocks, idx_of):
    t0 = time.time()
    metric = METRIC[task]; kind = "cls" if metric in ("AUROC", "AUPRC") else "reg"
    tr, va, te = load_task(task)
    ytr_raw = tr["Y"].values.astype(float)
    yva_raw = va["Y"].values.astype(float)
    use_log = task in LOG_TARGET

    Xtr = feats_for(tr["Drug"].astype(str).tolist(), blocks, idx_of)
    Xva = feats_for(va["Drug"].astype(str).tolist(), blocks, idx_of)
    Xte = feats_for(te["Drug"].astype(str).tolist(), blocks, idx_of)

    ytr = np.log1p(ytr_raw) if use_log else ytr_raw
    yva = np.log1p(yva_raw) if use_log else yva_raw

    Xall = np.vstack([Xtr, Xva]); yall = np.concatenate([ytr, yva])
    n = len(yall)
    if kind == "cls":
        folds = list(StratifiedKFold(NFOLD, shuffle=True, random_state=SEED).split(Xall, yall))
    else:
        folds = list(KFold(NFOLD, shuffle=True, random_state=SEED).split(Xall))

    oof = {}
    Sig_tr_all = blocks["morgan2"][np.array([idx_of[s] for s in (tr["Drug"].astype(str).tolist() + va["Drug"].astype(str).tolist())])]
    Sig_te = blocks["morgan2"][np.array([idx_of[s] for s in te["Drug"].astype(str).tolist()])]

    for name, fn in BASE:
        oof[name] = np.zeros(n)
    oof["knn"] = np.zeros(n)

    for f, (itr, iva) in enumerate(folds):
        Xa, ya = Xall[itr], yall[itr]
        Xb = Xall[iva]
        for name, fn in BASE:
            Xa_use = des_only(Xa) if name == "ridge" else Xa
            Xb_use = des_only(Xb) if name == "ridge" else Xb
            try:
                oof[name][iva] = fn(Xa_use, ya, Xb_use, kind, metric)
            except Exception as e:
                print(f"[warn] {task} {name} fold{f}: {e}", flush=True)
                oof[name][iva] = np.nan
        try:
            oof["knn"][iva] = fit_knn(Sig_tr_all[itr], ya, Sig_tr_all[iva], kind)
        except Exception as e:
            print(f"[warn] {task} knn fold{f}: {e}", flush=True)

    # ---- 贪心集成（Caruana）----
    names = [k for k in oof if np.isfinite(oof[k]).all()]
    def m_of(p):
        return score_metric(yall, p, metric)

    singles = {k: m_of(oof[k]) for k in names}
    # 方向：MAE 越小越好
    sign = -1.0 if metric == "MAE" else 1.0
    key = lambda v: (v * sign) if np.isfinite(v) else -1e9
    best = max(singles, key=lambda k: key(singles[k]))
    cur = oof[best].copy(); counts = {best: 1}; chosen = [best]
    best_m = singles[best]
    for step in range(1, ENS_STEPS):
        cand, cand_m = None, best_m
        for k in names:
            trial = (cur * step + oof[k]) / (step + 1)
            v = m_of(trial)
            if key(v) > key(cand_m):
                cand, cand_m = k, v
        if cand is None:
            break
        cur = (cur * step + oof[cand]) / (step + 1)
        counts[cand] = counts.get(cand, 0) + 1
        chosen.append(cand); best_m = cand_m
    ens_oof = cur
    w = {k: counts.get(k, 0) / sum(counts.values()) for k in names}

    # ---- train -> valid 诚实评估 ----
    va_pred, va_ens = {}, {}
    for name, fn in [(k, dict(BASE).get(k)) for k in names]:
        if fn is None:
            continue
        try:
            Xa_use = des_only(Xtr) if name == "ridge" else Xtr
            Xb_use = des_only(Xva) if name == "ridge" else Xva
            va_pred[name] = fn(Xa_use, ytr, Xb_use, kind, metric)
        except Exception as e:
            print(f"[warn] {task} valid-{name}: {e}", flush=True)
    if "knn" in names:
        va_pred["knn"] = fit_knn(Sig_tr_all[:len(ytr)], ytr, Sig_tr_all[len(ytr):], kind)
    for name in va_pred:
        va_ens[name] = score_metric(yva, va_pred[name], metric)
    if va_pred:
        blend = np.zeros(len(yva))
        for k, ww in w.items():
            if ww > 0 and k in va_pred:
                blend += ww * va_pred[k]
        va_ens["ENSEMBLE"] = score_metric(yva, blend, metric)

    # ---- 最终重训 -> test ----
    te_pred = {}
    for name, fn in [(k, dict(BASE).get(k)) for k in names if w.get(k, 0) > 0]:
        if fn is None:
            continue
        Xa_use = des_only(Xall) if name == "ridge" else Xall
        Xb_use = des_only(Xte) if name == "ridge" else Xte
        te_pred[name] = fn(Xa_use, yall, Xb_use, kind, metric)
    if w.get("knn", 0) > 0:
        te_pred["knn"] = fit_knn(Sig_tr_all, yall, Sig_te, kind)

    blend_te = np.zeros(len(te))
    for k, ww in w.items():
        if ww > 0 and k in te_pred:
            blend_te += ww * te_pred[k]
    if use_log:
        blend_te = np.expm1(blend_te)
        # Spearman 只看排序，保留单调即可

    res = dict(task=task, metric=metric, kind=kind, n_train=int(len(ytr)), n_test=int(len(te)),
               oof_single=singles, oof_ensemble=float(best_m),
               valid_single=va_ens, weights=w,
               ref=REF[task],
               comp_oof=float(comp_score(best_m, metric, REF[task])),
               comp_valid=float(comp_score(va_ens.get("ENSEMBLE", np.nan), metric, REF[task])),
               seconds=round(time.time() - t0, 1))
    np.savez_compressed(OUT / f"{task}_pred.npz", test=blend_te, oof=ens_oof, y=yall)
    print(f"[task] {task:<36} {metric:<9} OOF={best_m:.4f}  VAL={va_ens.get('ENSEMBLE', float('nan')):.4f}"
          f"  ref={REF[task]:.4f}  score(OOF)={res['comp_oof']:.2f}  {res['seconds']}s", flush=True)
    return res


def main():
    global N_DESC
    blocks = dict(np.load(FEAT / "feats.npz"))
    N_DESC = blocks["desc"].shape[1]
    print(f"[info] 描述符维度 = {N_DESC}", flush=True)
    smiles = np.load(FEAT / "smiles.npy", allow_pickle=True)
    idx_of = {s: i for i, s in enumerate(smiles.tolist())}
    tasks = sorted(METRIC)
    only = sys.argv[1:] or tasks
    results = []
    from multiprocessing import Pool
    with Pool(min(len(only), 8)) as pool:
        for r in pool.imap_unordered(_wrap, [(t, blocks, idx_of) for t in only]):
            results.append(r)
            with open(OUT / "results.json", "w") as f:
                json.dump(sorted(results, key=lambda x: x["task"]), f, indent=2, ensure_ascii=False)
    total = np.mean([r["comp_oof"] for r in results])
    print(f"\n[summary] 22 项平均（OOF 估计分）= {total:.4f}", flush=True)
    df = pd.DataFrame([{k: v for k, v in r.items() if not isinstance(v, dict)} for r in results])
    df.sort_values("comp_oof").to_csv(OUT / "summary.csv", index=False)
    print(df.to_string(index=False), flush=True)


def _wrap(args):
    return run_task(*args)


if __name__ == "__main__":
    main()
