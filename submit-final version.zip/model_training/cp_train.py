# -*- coding: utf-8 -*-
"""Chemprop 2.x D-MPNN：骨架折 OOF + test 预测，与 GBM/GNN 共用同一折"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch
from chemprop import data, featurizers, models, nn
from lightning import pytorch as pl

sys.path.insert(0, "/root/autodl-tmp/admet2")
import common as C

ROOT = "/root/autodl-tmp/admet2"
OUT = os.path.join(ROOT, "runs", "cp")


def prep(smiles, y, feat):
    pts, keep = [], []
    for i, s in enumerate(smiles):
        try:
            if y is None:
                p = data.MoleculeDatapoint.from_smi(str(s))
            else:
                p = data.MoleculeDatapoint.from_smi(str(s), [float(y[i])])
            pts.append(p)
            keep.append(i)
        except Exception:
            continue
    return data.MoleculeDataset(pts, feat), np.array(keep, dtype=np.int64)


def predict(trainer, model, dset, bs):
    dl = data.build_dataloader(dset, batch_size=bs, num_workers=0, shuffle=False)
    outs = trainer.predict(model, dataloaders=dl)
    if not outs:
        return np.array([])
    return torch.cat([o.reshape(-1) for o in outs]).numpy()


def run_task(task, nfold, epochs, seeds, bs, tag):
    tr_df, va_df, te_df = C.load_task(task)
    df = __import__("pandas").concat([tr_df, va_df], ignore_index=True)
    smiles = df["Drug"].astype(str).values
    y = df["Y"].astype(float).values
    te_smi = te_df["Drug"].astype(str).values
    metric = C.METRIC[task]
    is_cls = metric in ("AUROC", "AUPRC")

    use_log = task in C.LOG_TARGET
    yt = np.log1p(np.clip(y, 0, None)) if use_log else y.copy()
    mu, sd = (float(yt.mean()), float(yt.std()) + 1e-9) if not is_cls else (0.0, 1.0)

    folds, kind = C.scaffold_folds(smiles, y if is_cls else yt, nfold=nfold, seed=7,
                                   kind="cls" if is_cls else "reg")
    feat = featurizers.SimpleMoleculeMolGraphFeaturizer()

    oof = np.full(len(smiles), np.nan)
    te_acc = []

    for fi, (tr_i, va_i) in enumerate(folds):
        t0 = time.time()
        dtr, ktr = prep(smiles[tr_i], (yt[tr_i] - mu) / sd if not is_cls else y[tr_i], feat)
        dva, kva = prep(smiles[va_i], (yt[va_i] - mu) / sd if not is_cls else y[va_i], feat)
        dte, _ = prep(te_smi, None, feat)

        mp = nn.BondMessagePassing(d_h=300, depth=3)
        agg = nn.MeanAggregation()
        if is_cls:
            ffn = nn.BinaryClassificationFFN(input_dim=300, hidden_dim=300, n_layers=1)
        else:
            ffn = nn.RegressionFFN(input_dim=300, hidden_dim=300, n_layers=1)
        model = models.MPNN(mp, agg, ffn, batch_norm=True)

        tr_dl = data.build_dataloader(dtr, batch_size=bs, num_workers=0, shuffle=True)
        va_dl = data.build_dataloader(dva, batch_size=bs, num_workers=0, shuffle=False)

        trainer = pl.Trainer(max_epochs=epochs, accelerator="gpu", devices=1,
                             logger=False, enable_checkpointing=False,
                             enable_progress_bar=False, enable_model_summary=False)
        trainer.fit(model, train_dataloaders=tr_dl, val_dataloaders=va_dl)

        pv = predict(trainer, model, dva, bs)
        if not is_cls:
            pv = pv * sd + mu
            if use_log:
                pv = np.expm1(pv)
        oof[va_i[kva]] = pv

        pt = predict(trainer, model, dte, bs)
        if not is_cls:
            pt = pt * sd + mu
            if use_log:
                pt = np.expm1(pt)
        te_acc.append(pt)
        print(f"  [{task}] fold{fi} n_tr={len(dtr)} n_va={len(dva)} "
              f"{time.time() - t0:.1f}s", flush=True)

    nmin = min(len(x) for x in te_acc)
    te = np.mean([x[:nmin] for x in te_acc], axis=0)

    raw = C.score_metric(y, oof, metric)
    print(f"[{task}] OOF {metric}={raw:.4f} score={C.comp_score(raw, metric, C.REF[task]):.3f} "
          f"kind={kind}", flush=True)

    os.makedirs(OUT, exist_ok=True)
    np.savez(os.path.join(OUT, f"{task}_{tag}.npz"), oof=oof, test=te, y=y)
    return {"task": task, "metric": metric, "oof_raw": float(raw),
            "oof_score": float(C.comp_score(raw, metric, C.REF[task])),
            "kind": kind, "n": int(len(smiles))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", default="")
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--epochs", type=int, default=50)
    ap.add_argument("--seeds", type=int, default=1)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--tag", default="A")
    a = ap.parse_args()

    tasks = [t.strip() for t in a.tasks.split(",") if t.strip()] or list(C.REF.keys())
    os.makedirs(OUT, exist_ok=True)
    res = []
    for t in tasks:
        t0 = time.time()
        try:
            r = run_task(t, a.folds, a.epochs, a.seeds, a.bs, a.tag)
            res.append(r)
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"[{t}] FAILED {e}", flush=True)
        print(f"[{t}] total {time.time() - t0:.1f}s", flush=True)
        with open(os.path.join(OUT, f"results_{a.tag}.json"), "w") as f:
            json.dump(res, f, indent=1)

    ok = [r for r in res if np.isfinite(r["oof_score"])]
    if ok:
        print(f"\n[SUMMARY] n={len(ok)} mean_score={np.mean([r['oof_score'] for r in ok]):.4f}",
              flush=True)


if __name__ == "__main__":
    main()
