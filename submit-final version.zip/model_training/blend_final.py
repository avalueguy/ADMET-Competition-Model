# -*- coding: utf-8 -*-
"""多候选模型贪心融合：扫描 runs/gbm 与 runs/gnn2 下所有该任务的预测，择优加权，产出提交"""
import json, argparse, glob, os
import numpy as np
import pandas as pd
from pathlib import Path
from scipy.stats import rankdata
from common import REF, METRIC, LOG_TARGET, score_metric, comp_score, load_task, ROOT

RUNS = ROOT / "runs"
STEPS = 30


def rank01(v):
    return rankdata(v) / len(v)


def collect(task):
    """收集所有可用预测"""
    out = []
    tiers = [("gbm", RUNS / "gbm" / f"{task}_gbm*.npz"),
             ("gnn2", RUNS / "gnn2" / f"{task}_gnn2_*.npz"),
             ("gnn", RUNS / "gnn" / f"{task}_gnn.npz")]
    for tier, pat in tiers:
        for f in sorted(glob.glob(str(pat))):
            try:
                d = np.load(f)
            except Exception:
                continue
            nm = Path(f).stem.replace(f"{task}_", "")
            out.append((nm, d["oof"], d["test"], d["y"]))
    # 只保留 y 一致且长度正确的
    if not out:
        return []
    y0 = out[0][3]
    keep = [o for o in out if len(o[3]) == len(y0) and np.allclose(o[3], y0)]
    return keep


def greedy(y, oofs, names, metric):
    sign = -1.0 if metric == "MAE" else 1.0
    def key(v):
        return v * sign if np.isfinite(v) else -1e9
    singles = {n: score_metric(y, o, metric) for n, o in zip(names, oofs)}
    best = max(names, key=lambda n: key(singles[n]))
    cur = oofs[names.index(best)].copy()
    counts = {best: 1}
    best_m = singles[best]
    for step in range(1, STEPS):
        cand, cand_m = None, best_m
        for n, o in zip(names, oofs):
            tr = (cur * step + o) / (step + 1)
            v = score_metric(y, tr, metric)
            if key(v) > key(cand_m):
                cand, cand_m = n, v
        if cand is None:
            break
        cur = (cur * step + oofs[names.index(cand)]) / (step + 1)
        counts[cand] = counts.get(cand, 0) + 1
        best_m = cand_m
    w = {k: v / sum(counts.values()) for k, v in counts.items()}
    return best_m, w, singles


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="v2")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    tpl = pd.read_csv(ROOT / "upload_template.csv")
    # drug_id 一律按原始字符串读取，避免纯数字 ID 被数值化（5348064 -> 5348064.0）或丢尾空格
    tpl_id = pd.read_csv(ROOT / "upload_template.csv", encoding="utf-8",
                         dtype=str, keep_default_na=False)["drug_id"].tolist()
    tasks = list(dict.fromkeys(tpl["task"].tolist()))
    report, preds = [], {}
    te_smiles = {}
    te_drugid = {}

    for task in tasks:
        metric = METRIC[task]; ref = REF[task]
        kind = "cls" if metric in ("AUROC", "AUPRC") else "reg"
        tr, va, te = load_task(task)
        nte = len(te)
        te_smiles[task] = te["Drug"].astype(str).tolist()
        # drug_id 以官方 test.csv 为准：上传模板中个别行存在编码损坏（ñ 被存成 帽）
        teraw = pd.read_csv(ROOT / "data_benchmark" / task / "test.csv", encoding="utf-8-sig",
                            dtype=str, keep_default_na=False)
        teraw.columns = [c.strip().strip('"') for c in teraw.columns]
        te_drugid[task] = [str(x) for x in teraw["Drug_ID"].tolist()]
        assert len(te_drugid[task]) == nte, f"Drug_ID 长度不符: {task}"
        cands = collect(task)
        if not cands:
            print(f"[miss] {task}"); continue
        y = cands[0][3]
        names = [c[0] for c in cands]
        oofs = [c[1] for c in cands]
        tests = [c[2] for c in cands]

        # 候选质量门槛：单模型明显更弱的不允许进权重（防止贪心过拟合 OOF 噪声）
        pre = {n: score_metric(y, o, metric) for n, o in zip(names, oofs)}
        if metric == "MAE":
            bv = min(pre.values())
            ki = [i for i, n in enumerate(names) if pre[n] <= bv / 0.92]
        else:
            bv = max(pre.values())
            ki = [i for i, n in enumerate(names) if pre[n] >= bv * 0.92]
        names = [names[i] for i in ki]; oofs = [oofs[i] for i in ki]; tests = [tests[i] for i in ki]

        # 同一 GNN 架构的不同变体高度相关，只保留该任务上最优的一个
        g2 = [i for i, n in enumerate(names) if n.startswith("gnn2_")]
        if len(g2) > 1:
            bt = (min(g2, key=lambda i: pre[names[i]]) if metric == "MAE"
                  else max(g2, key=lambda i: pre[names[i]]))
            drop = set(g2) - {bt}
            names = [n for i, n in enumerate(names) if i not in drop]
            oofs = [o for i, o in enumerate(oofs) if i not in drop]
            tests = [t for i, t in enumerate(tests) if i not in drop]

        # 原始值空间贪心
        m_raw, w_raw, singles = greedy(y, oofs, names, metric)
        # 秩空间贪心（对 Spearman / AUPRC 往往更稳）
        oofs_r = [rank01(o) for o in oofs]
        tests_r = [rank01(t) for t in tests]
        m_rank, w_rank, _ = greedy(y, oofs_r, names, metric)

        if metric in ("Spearman", "AUPRC", "AUROC") and m_rank > m_raw:
            mode, w, m = "rank", w_rank, m_rank
        else:
            mode, w, m = "raw", w_raw, m_raw
        if mode == "raw":
            test = sum(w[k] * tests[names.index(k)] for k in w)
        else:
            test = sum(w[k] * tests_r[names.index(k)] for k in w)

        if kind == "reg":
            yv = np.concatenate([tr["Y"].values.astype(float), va["Y"].values.astype(float)])
            lo, hi = np.nanmin(yv), np.nanmax(yv); span = hi - lo
            test = np.clip(test, lo - 0.02 * span, hi + 0.02 * span)
        else:
            test = np.clip(test, 0.0, 1.0)

        assert len(test) == nte and np.all(np.isfinite(test)), task
        preds[task] = test
        desc = " + ".join(f"{k}*{v:.2f}" for k, v in sorted(w.items(), key=lambda x: -x[1]))
        report.append(dict(task=task, metric=metric, ref=ref, n_test=nte, mode=mode,
                           oof_metric=round(float(m), 4), score=round(float(comp_score(m, metric, ref)), 3),
                           blend=desc, singles=" ".join(f"{k}:{v:.3f}" for k, v in singles.items())))

    df = pd.DataFrame(report)
    print(df[["task", "metric", "ref", "oof_metric", "score", "mode", "blend"]].to_string(index=False))
    print(f"\n[projected] OOF 估计总分 = {df['score'].mean():.3f}   (线上 51.314)")
    for r in report:
        print(f"  {r['task'][:32]:<32} {r['singles']}")

    yv = np.zeros(len(tpl))
    id_lut = {}
    pos_by_task = tpl.groupby("task").indices
    for task in tasks:
        pos = np.asarray(pos_by_task[task])
        yv[pos] = preds[task]
        trows = tpl.iloc[pos]
        assert trows["smiles"].tolist() == list(te_smiles[task]), f"smiles 顺序不一致: {task}"
        ids = te_drugid[task]
        assert len(ids) == len(pos), f"drug_id 长度 {len(ids)} != {len(pos)}: {task}"
        for k, i in enumerate(pos.tolist()):
            id_lut[int(i)] = ids[k]
    miss = [i for i in range(len(tpl)) if i not in id_lut]
    print(f"[id] drug_id 覆盖 {len(id_lut)}/{len(tpl)}  缺失={len(miss)}")
    assert not miss, f"有 {len(miss)} 行缺少 drug_id"
    assert np.all(np.isfinite(yv)), "存在非有限预测"
    # drug_id 一律对齐官方 test.csv 原值：平台以其为 expected 逐字比对（含 5348064.0 这种形式、
    # 也容忍两侧空白），而 template 存在 GBK 误码（ñ→帽、α→伪、á→谩）与数值化差异
    # test.csv 中为空的行（官方提交中也留空，如 herg#61），保留 template 原值
    dv = list(tpl_id)
    replaced = []
    for task in tasks:
        pos = np.asarray(pos_by_task[task]).tolist()
        ids = te_drugid[task]
        assert len(ids) == len(pos), f"drug_id 长度不符: {task}"
        for k, i in enumerate(pos):
            v = ids[k]
            if v != "" and v != dv[i]:
                replaced.append((int(i), dv[i], v))
                dv[i] = v
    print(f"[id] 按 test.csv 对齐 {len(replaced)} 行")
    for r in replaced[:8]:
        print(f"      row {r[0]}: {r[1]!r} -> {r[2]!r}")
    # template 自身缺失 Drug_ID 的行（官方提交中同样为空），保留空值；其余不得为空
    tpl_empty = [i for i, x in enumerate(tpl_id) if x.strip() == ""]
    empty = [i for i, v in enumerate(dv) if v.strip() == ""]
    print(f"[id] 空 drug_id = {len(empty)}（模板原本空 {len(tpl_empty)}）-> {tpl_empty}")
    assert empty == tpl_empty, "出现了模板中不存在的空 drug_id"
    out = tpl.copy(); out["y_pred"] = yv; out["drug_id"] = dv
    outp = Path(a.out) if a.out else (ROOT / f"submission_{a.tag}.csv")
    out.to_csv(outp, index=False)
    df.to_csv(ROOT / f"report_{a.tag}.csv", index=False)
    json.dump(dict(total=float(df["score"].mean()), rows=report),
              open(ROOT / f"report_{a.tag}.json", "w"), indent=2, ensure_ascii=False)
    print(f"\n[saved] {outp} rows={len(out)} 空值={out['y_pred'].isna().sum()}")


if __name__ == "__main__":
    main()
