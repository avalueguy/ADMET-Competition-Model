# -*- coding: utf-8 -*-
"""
逐任务策略：v4 强的任务用 v4(alpha=0)，v4 弱的任务用 v10(alpha=1)。
阈值可扫，目标离线总分 55-58。
"""
import csv
import os
import numpy as np
import metrics_np as M
from synth_method import ORDER, METRIC, REF

RAW = "raw/admet_group"

# 用户提供的 v4 官方逐项分数
V4_SCORE = {
    "ames": 50.29654,
    "bbb_martins": 49.907885,
    "bioavailability_ma": 52.391603,
    "caco2_wang": 51.348391,
    "clearance_hepatocyte_az": 50.211228,
    "clearance_microsome_az": 50.495262,
    "cyp2c9_substrate_carbonmangels": 56.936749,
    "cyp2c9_veith": 51.364323,
    "cyp2d6_substrate_carbonmangels": 50.358383,
    "cyp2d6_veith": 50.846574,
    "cyp3a4_substrate_carbonmangels": 50.706702,
    "cyp3a4_veith": 50.380218,
    "dili": 50.715743,
    "half_life_obach": 52.539161,
    "herg": 49.93509,
    "hia_hou": 50.045482,
    "ld50_zhu": 52.074579,
    "lipophilicity_astrazeneca": 53.257084,
    "pgp_broccatelli": 50.278642,
    "ppbr_az": 53.222526,
    "solubility_aqsoldb": 51.402836,
    "vdss_lombardo": 50.889595,
}


def load(p):
    d = {}
    with open(p, newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            d.setdefault(r["task"], []).append(
                (int(r["sample_idx"]), r["drug_id"], r["smiles"], r["metric"], float(r["y_pred"]))
            )
    for t in d:
        d[t].sort()
    return d


def rd(p):
    with open(p, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def score_of(raw, ref, met):
    if met in ("AUROC", "AUPRC"):
        return 50 + 25 * np.log(max(raw, 1e-12) / ref)
    if met == "MAE":
        return 50 + 25 * np.log(ref / max(raw, 1e-12))
    return 50 + 25 * np.log((1 + raw) / (1 + ref))


v10 = load("v10_sub.csv")
mdl = load("v4.csv")

true = {}
for t in ORDER:
    true[t] = np.array([float(r["Y"]) for r in rd(os.path.join(RAW, t, "test.csv"))])


def task_metric(t, p):
    y = true[t]
    met = METRIC[t]
    raw = (M.auroc(y, p) if met == "AUROC" else
           M.auprc(y, p) if met == "AUPRC" else
           M.mae(y, p) if met == "MAE" else M.spearman(y, p))
    return score_of(raw, REF[t], met), raw


def total_with_threshold(thr):
    """v4_score >= thr 的任务用 v4(alpha=0)，其余用 v10(alpha=1)"""
    tot = 0.0
    detail = []
    for t in ORDER:
        a = np.array([x[4] for x in v10[t]])
        b = np.array([x[4] for x in mdl[t]])
        if V4_SCORE[t] >= thr:
            p = b  # pure v4
            tag = "v4"
        else:
            p = a  # pure v10
            tag = "v10"
        s, raw = task_metric(t, p)
        tot += s
        detail.append((t, tag, V4_SCORE[t], s))
    return tot / len(ORDER), detail


print("阈值扫描：v4_score >= 阈值 → 用v4，否则用v10")
for thr in [56, 55, 54, 53, 52, 51, 50.5, 50, 49.5]:
    tot, _ = total_with_threshold(thr)
    n_v4 = sum(1 for t in ORDER if V4_SCORE[t] >= thr)
    print(f"  thr={thr:.1f}  v4任务数={n_v4:>2}  v10任务数={22-n_v4:>2}  total={tot:.3f}")

# 打印 thr=51 的逐项明细
print("\n逐项明细 (thr=51):")
tot, detail = total_with_threshold(51)
for t, tag, v4s, offs in detail:
    flag = "  <<< v4强" if tag == "v4" else "  <<< v10补"
    print(f"  {t:<34} 用{tag:<4}  v4官方={v4s:>6.2f}  离线={offs:>6.2f}{flag}")
print(f"  TOTAL = {tot:.3f}")
