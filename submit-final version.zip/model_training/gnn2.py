# -*- coding: utf-8 -*-
"""
D-MPNN v2：修正初始消息来源（原子特征），pooled 后接 LayerNorm，可选接入描述符
用于与 GBM 对比与融合
"""
import json, time, argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.preprocessing import StandardScaler
from rdkit import Chem, RDLogger
RDLogger.DisableLog("rdApp.*")
from common import (REF, METRIC, LOG_TARGET, score_metric, comp_score,
                    load_task, scaffold_folds, FEAT, ROOT)

OUT = ROOT / "runs" / "gnn2"
OUT.mkdir(parents=True, exist_ok=True)

ALLOWED_NUM = [1, 5, 6, 7, 8, 9, 11, 12, 14, 15, 16, 17, 19, 20, 26, 29, 30, 33,
               34, 35, 38, 42, 51, 53, 55, 56, 80, 82]
NUM_IDX = {z: i for i, z in enumerate(ALLOWED_NUM)}
CHIRAL = {"CHI_UNSPECIFIED": 0, "CHI_TETRAHEDRAL_CW": 1, "CHI_TETRAHEDRAL_CCW": 2,
          "CHI_OTHER": 3}
ATOM_DIM = len(ALLOWED_NUM) + 1 + 6 + 5 + 5 + 6 + 1 + 1 + 1 + 4
BOND_DIM = 4 + 1 + 1 + 6
BT = {Chem.BondType.SINGLE: 0, Chem.BondType.DOUBLE: 1, Chem.BondType.TRIPLE: 2,
      Chem.BondType.AROMATIC: 3}


def atom_feats(a):
    f = np.zeros(ATOM_DIM, dtype=np.float32)
    f[NUM_IDX.get(a.GetAtomicNum(), len(ALLOWED_NUM))] = 1.0
    o = len(ALLOWED_NUM) + 1
    f[o + min(a.GetTotalDegree(), 5)] = 1.0; o += 6
    f[o + min(max(a.GetFormalCharge(), -2), 2) + 2] = 1.0; o += 5
    f[o + min(a.GetTotalNumHs(), 4)] = 1.0; o += 5
    f[o + {"SP": 0, "SP2": 1, "SP3": 2, "SP3D": 3, "SP3D2": 4}.get(str(a.GetHybridization()), 5)] = 1.0; o += 6
    f[o] = 1.0 if a.GetIsAromatic() else 0.0; o += 1
    f[o] = 1.0 if a.IsInRing() else 0.0; o += 1
    f[o] = a.GetMass() * 0.01; o += 1
    f[o + CHIRAL.get(str(a.GetChiralTag()), 0)] = 1.0
    return f


def bond_feats(b):
    f = np.zeros(BOND_DIM, dtype=np.float32)
    f[BT.get(b.GetBondType(), 0)] = 1.0
    f[4] = 1.0 if b.GetIsConjugated() else 0.0
    f[5] = 1.0 if b.IsInRing() else 0.0
    f[6 + {"STEREONONE": 0, "STEREOANY": 1, "STEREOZ": 2, "STEREOE": 3,
           "STEREOCIS": 4, "STEREOTRANS": 5}.get(str(b.GetStereo()), 0)] = 1.0
    return f


def mol_to_graph(smi):
    mol = Chem.MolFromSmiles(smi)
    if mol is None or mol.GetNumAtoms() == 0:
        return None
    af = np.stack([atom_feats(a) for a in mol.GetAtoms()])
    bfs, src, dst = [], [], []
    for b in mol.GetBonds():
        i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
        f = bond_feats(b)
        bfs.append(f); src.append(i); dst.append(j)
        bfs.append(f); src.append(j); dst.append(i)
    if bfs:
        bf = np.stack(bfs); e = np.stack([src, dst], 1).astype(np.int64)
    else:
        bf = np.zeros((0, BOND_DIM), np.float32); e = np.zeros((0, 2), np.int64)
    return af, bf, e


def make_batch(graphs, descs, idxs, device):
    A, B, E, MO = [], [], [], []
    off = 0
    for k, i in enumerate(idxs):
        g = graphs[i]
        if g is None:
            af = np.zeros((1, ATOM_DIM), np.float32)
            bf = np.zeros((0, BOND_DIM), np.float32)
            ee = np.zeros((0, 2), np.int64)
        else:
            af, bf, ee = g
        A.append(af); B.append(bf); E.append(ee + off)
        MO.append(np.full(len(af), k, np.int64))
        off += len(af)
    return (torch.from_numpy(np.concatenate(A)).to(device),
            torch.from_numpy(np.concatenate(B)).to(device),
            torch.from_numpy(np.concatenate(E)).to(device),
            torch.from_numpy(np.concatenate(MO)).to(device),
            torch.from_numpy(np.asarray(descs, np.float32)).to(device),
            len(idxs))


class Enc(nn.Module):
    def __init__(self, adim, bdim, hidden=300, depth=3, dropout=0.1):
        super().__init__()
        self.Wi = nn.Linear(adim, hidden)
        self.Wh = nn.Linear(adim, hidden)          # 初始消息：由原子特征生成（Chemprop）
        self.Wm = nn.Linear(hidden, hidden, bias=False)
        self.Wo = nn.Linear(bdim, hidden, bias=False)
        self.Wm2 = nn.Linear(hidden, hidden, bias=False)
        self.Wp = nn.Linear(hidden, hidden)
        self.ln = nn.LayerNorm(hidden)
        self.depth = depth
        self.drop = nn.Dropout(dropout)

    def forward(self, atom, bond, e, molof, n):
        h0 = F.relu(self.Wi(atom))
        m = F.relu(self.Wh(atom))[e[:, 0]]        # 每条有向键的初始消息，源自源原子
        for _ in range(self.depth):
            M = torch.zeros(h0.size(0), h0.size(1), device=h0.device, dtype=h0.dtype)
            M.index_add_(0, e[:, 1], m)
            h = F.relu(h0 + self.Wm(M))
            m = F.relu(h[e[:, 0]] + self.Wo(bond))
        M = torch.zeros_like(h0)
        M.index_add_(0, e[:, 1], m)
        hf = F.relu(h0 + self.Wm2(M))
        p = F.relu(self.Wp(hf))
        z = torch.zeros(n, p.size(1), device=p.device, dtype=p.dtype)
        z.index_add_(0, molof, p)
        return self.ln(z)


class Net(nn.Module):
    def __init__(self, adim, bdim, n_desc, hidden=300, depth=3, dropout=0.1, ffn_h=600):
        super().__init__()
        self.enc = Enc(adim, bdim, hidden, depth, dropout)
        self.use_desc = n_desc > 0
        d = hidden + n_desc
        self.ffn = nn.Sequential(
            nn.Linear(d, ffn_h), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(ffn_h, ffn_h), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(ffn_h, 1))

    def forward(self, atom, bond, e, molof, desc, n):
        z = self.enc(atom, bond, e, molof, n)
        if self.use_desc:
            z = torch.cat([z, desc], 1)
        return self.ffn(z).squeeze(1)


def run(task, blocks, idx_of, folds_n, seeds, max_epochs, device, bs, use_desc,
        lr=1e-3, tag=""):
    t0 = time.time()
    metric = METRIC[task]
    kind = "cls" if metric in ("AUROC", "AUPRC") else "reg"
    use_log = task in LOG_TARGET
    tr, va, te = load_task(task)
    sm_tr = tr["Drug"].astype(str).tolist(); sm_va = va["Drug"].astype(str).tolist()
    sm_te = te["Drug"].astype(str).tolist()
    smiles = sm_tr + sm_va
    y_raw = np.concatenate([tr["Y"].values.astype(float), va["Y"].values.astype(float)])
    y = np.log1p(y_raw) if use_log else y_raw

    gcache = {}
    def G(s):
        if s not in gcache:
            gcache[s] = mol_to_graph(s)
        return gcache[s]
    graphs_ref = [G(s) for s in smiles]; graphs_te = [G(s) for s in sm_te]
    if use_desc:
        desc_all = np.nan_to_num(blocks["desc"][np.array([idx_of[s] for s in smiles])],
                                 nan=0.0, posinf=0.0, neginf=0.0)
        desc_te = np.nan_to_num(blocks["desc"][np.array([idx_of[s] for s in sm_te])],
                                nan=0.0, posinf=0.0, neginf=0.0)
        ndesc = desc_all.shape[1]
    else:
        desc_all = np.zeros((len(smiles), 0), np.float32)
        desc_te = np.zeros((len(sm_te), 0), np.float32)
        ndesc = 0

    n = len(y)
    folds, scheme = scaffold_folds(smiles, y, folds_n, seed=7, kind=kind)
    oof = np.zeros(n); best_eps = []

    for fi, (itr, iva) in enumerate(folds):
        if use_desc:
            sc = StandardScaler().fit(desc_all[itr])
            Dtr = np.clip(sc.transform(desc_all[itr]), -10, 10).astype(np.float32)
            Dva = np.clip(sc.transform(desc_all[iva]), -10, 10).astype(np.float32)
        else:
            Dtr = desc_all[itr]; Dva = desc_all[iva]
        ytr = y[itr]
        if kind == "reg":
            ym, ys = ytr.mean(), ytr.std() + 1e-6; tgt = (ytr - ym) / ys
        else:
            tgt = ytr
        sp, se = [], []
        for sd in range(seeds):
            torch.manual_seed(1000 * sd + fi); np.random.seed(1000 * sd + fi)
            model = Net(ATOM_DIM, BOND_DIM, ndesc).to(device)
            opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-5)
            nb = int(np.ceil(len(itr) / bs))
            sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=lr,
                                                        total_steps=max_epochs * nb,
                                                        pct_start=0.08)
            if kind == "cls":
                pos = max(tgt.sum(), 1.0); neg = len(tgt) - pos
                pw = torch.tensor([neg / pos], device=device, dtype=torch.float32)
                lossfn = nn.BCEWithLogitsLoss(pos_weight=pw)
            else:
                lossfn = nn.SmoothL1Loss(beta=0.1) if metric == "MAE" else nn.MSELoss()
            gi_va = [int(k) for k in iva]
            best_m, best_p, best_ep, bad = None, None, max_epochs, 0
            for ep in range(max_epochs):
                model.train()
                perm = np.random.permutation(len(itr))
                for b0 in range(0, len(itr), bs):
                    bidx = perm[b0:b0 + bs]
                    gi = [int(itr[k]) for k in bidx]
                    atom, bond, e, molof, d, nb2 = make_batch(graphs_ref, Dtr[bidx], gi, device)
                    out = model(atom, bond, e, molof, d, nb2)
                    t = torch.tensor(tgt[bidx], dtype=torch.float32, device=device)
                    loss = lossfn(out, t)
                    opt.zero_grad(); loss.backward()
                    nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                    opt.step()
                    try: sched.step()
                    except Exception: pass
                if ep >= 10:
                    model.eval()
                    with torch.no_grad():
                        atom, bond, e, molof, d, nb2 = make_batch(graphs_ref, Dva, gi_va, device)
                        p = model(atom, bond, e, molof, d, nb2).cpu().numpy()
                    if kind == "reg":
                        p = p * ys + ym
                    mm = score_metric(y[iva], p, metric)
                    better = (best_m is None or not np.isfinite(best_m)
                              or (mm < best_m if metric == "MAE" else mm > best_m))
                    if better and np.isfinite(mm):
                        best_m, best_p, best_ep, bad = mm, p, ep + 1, 0
                    else:
                        bad += 1
                        if bad >= 30:
                            break
            if best_p is None:
                best_p = np.zeros(len(iva))
            sp.append(best_p); se.append(best_ep)
        oof[iva] = np.mean(sp, 0); best_eps.extend(se)

    oof_m = score_metric(y, oof, metric)
    E = max(20, int(np.median(best_eps)))

    if use_desc:
        sc = StandardScaler().fit(desc_all)
        Dall = np.clip(sc.transform(desc_all), -10, 10).astype(np.float32)
        Dte = np.clip(sc.transform(desc_te), -10, 10).astype(np.float32)
    else:
        Dall = desc_all; Dte = desc_te
    if kind == "reg":
        ym, ys = y.mean(), y.std() + 1e-6; tgt = (y - ym) / ys
    else:
        tgt = y
    allpred = np.zeros(len(sm_te))
    for sd in range(seeds):
        torch.manual_seed(2000 + sd); np.random.seed(2000 + sd)
        model = Net(ATOM_DIM, BOND_DIM, ndesc).to(device)
        opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-5)
        nb = int(np.ceil(n / bs))
        sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=lr, total_steps=E * nb,
                                                    pct_start=0.08)
        if kind == "cls":
            pos = max(tgt.sum(), 1.0); neg = len(tgt) - pos
            pw = torch.tensor([neg / pos], device=device, dtype=torch.float32)
            lossfn = nn.BCEWithLogitsLoss(pos_weight=pw)
        else:
            lossfn = nn.SmoothL1Loss(beta=0.1) if metric == "MAE" else nn.MSELoss()
        snaps = []
        for ep in range(E):
            model.train()
            perm = np.random.permutation(n)
            for b0 in range(0, n, bs):
                bidx = perm[b0:b0 + bs]
                gi = [int(k) for k in bidx]
                atom, bond, e, molof, d, nb2 = make_batch(graphs_ref, Dall[bidx], gi, device)
                out = model(atom, bond, e, molof, d, nb2)
                t = torch.tensor(tgt[bidx], dtype=torch.float32, device=device)
                loss = lossfn(out, t)
                opt.zero_grad(); loss.backward()
                nn.utils.clip_grad_norm_(model.parameters(), 5.0)
                opt.step()
                try: sched.step()
                except Exception: pass
            if ep >= E - 5:
                model.eval()
                with torch.no_grad():
                    gi = list(range(len(sm_te)))
                    atom, bond, e, molof, d, nb2 = make_batch(graphs_te, Dte, gi, device)
                    snaps.append(model(atom, bond, e, molof, d, nb2).cpu().numpy())
        p = np.mean(snaps, 0)
        if kind == "reg":
            p = p * ys + ym
        allpred += p / seeds
    if use_log:
        allpred = np.expm1(allpred)
        oof = np.expm1(oof)
    if kind == "reg":
        yr = np.expm1(y) if use_log else y
        lo, hi = float(np.min(yr)), float(np.max(yr)); span = hi - lo
        allpred = np.clip(allpred, lo - 0.05 * span, hi + 0.05 * span)
        oof = np.clip(oof, lo - 0.05 * span, hi + 0.05 * span)

    res = dict(task=task, metric=metric, kind=kind, n=int(n), n_test=len(sm_te),
               oof=float(oof_m), ref=REF[task], cv=scheme, E=int(E), desc=bool(use_desc),
               lr=lr, comp=float(comp_score(oof_m, metric, REF[task])),
               seconds=round(time.time() - t0, 1))
    np.savez_compressed(OUT / f"{task}_gnn2{tag}.npz", test=allpred, oof=oof, y=y)
    print(f"[gnn2{tag}] {task[:30]:<30} {metric:<9} OOF={oof_m:.4f} ref={REF[task]:.4f} "
          f"score={res['comp']:.2f} E={E} desc={use_desc} {res['seconds']}s", flush=True)
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", nargs="*", default=None)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--epochs", type=int, default=200)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--nodesc", action="store_true")
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--tag", default="")
    a = ap.parse_args()
    tasks = a.tasks or sorted(METRIC)
    blocks = dict(np.load(FEAT / "feats.npz"))
    smiles_all = np.load(FEAT / "smiles.npy", allow_pickle=True)
    idx_of = {s: i for i, s in enumerate(smiles_all.tolist())}
    device = "cuda" if torch.cuda.is_available() else "cpu"
    results = []
    rf = OUT / f"results{ a.tag }.json"
    for t in tasks:
        try:
            r = run(t, blocks, idx_of, a.folds, a.seeds, a.epochs, device, a.bs,
                    (not a.nodesc), a.lr, a.tag)
        except Exception as e:
            import traceback; traceback.print_exc(); r = dict(task=t, error=str(e))
        results.append(r)
        json.dump(results, open(rf, "w"), indent=2, ensure_ascii=False)
    ok = [r for r in results if "comp" in r]
    if ok:
        print(f"\n[summary{ a.tag }] {len(ok)} 项平均 = {np.mean([r['comp'] for r in ok]):.4f}", flush=True)


if __name__ == "__main__":
    main()
