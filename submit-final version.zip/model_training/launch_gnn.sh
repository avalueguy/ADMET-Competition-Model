#!/bin/bash
cd /root/autodl-tmp/admet2 || exit 1
T="ppbr_az solubility_aqsoldb lipophilicity_astrazeneca ld50_zhu clearance_hepatocyte_az clearance_microsome_az half_life_obach vdss_lombardo cyp3a4_veith cyp2d6_veith"
/root/miniconda3/bin/python gnn2.py --tasks $T --seeds 2 --epochs 60 --tag _A > _gnn_full.log 2>&1
echo GNNALLDONE >> _gnn_full.log
