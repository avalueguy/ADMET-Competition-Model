# -*- coding: utf-8 -*-
"""真模型基线：只用比赛数据集 train/valid 训练，预测 test，输出提交

特征   : Morgan count FP (2048, r=2) + MACCS keys (167) + 理化描述符 (~14)
验证   : Murcko 骨架分组 5-fold（同一骨架不跨折），报告 OOF 指标
模型   : 每任务独立 LightGBM（分类任务用二分类，回归任务用 L2）
提交   : 全部 train+valid 重训 -> 预测 data_benchmark/<task>/test.csv

不使用任何 test 标签、不使用历史提交、不做后处理。
"""
import csv
import json
import os

import numpy as np
import pandas as pd

from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, Descriptors, MACCSkeys
from rdkit.Chem.Scaffolds import MurckoScaffold

RDLogger.DisableLog("rdApp.*")

ORDER = ["ames", "bbb_martins", "bioavailability_ma", "caco2_wang",
         "clearance_hepatocyte_az", "clearance_microsome_az",
         "cyp2c9_substrate_carbonmangels", "cyp2c9_veith",
         "cyp2d6_substrate_carbonmangels", "cyp2d6_veith",
         "cyp3a4_substrate_carbonmangels", "cyp3a4_veith", "dili",
         "half_life_obach", "herg", "hia_hou", "ld50_zhu",
         "lipophilicity_astrazeneca", "pgp_broccatelli", "ppbr_az",
         "solubility_aqsoldb", "vdss_lombardo"]

METRIC = {"ames": "AUROC", "bbb_martins": "AUROC", "bioavailability_ma": "AUROC",
          "caco2_wang": "MAE", "clearance_hepatocyte_az": "Spearman",
          "clearance_microsome_az": "Spearman",
          "cyp2c9_substrate_carbonmangels": "AUPRC", "cyp2c9_veith": "AUPRC",
          "cyp2d6_substrate_carbonmangels": "AUPRC", "cyp2d6_veith": "AUPRC",
          "cyp3a4_substrate_carbonmangels": "AUROC", "cyp3a4_veith": "AUPRC",
          "dili": "AUROC", "half_life_obach": "Spearman", "herg": "AUROC",
          "hia_hou": "AUROC", "ld50_zhu": "MAE",
          "lipophilicity_astrazeneca": "MAE", "pgp_broccatelli": "AUROC",
          "ppbr_az": "MAE", "solubility_aqsoldb": "MAE",
          "vdss_lombardo": "Spearman"}

REG = {"caco2_wang", "clearance_hepatocyte_az", "clearance_microsome_az",
       "half_life_obach", "ld50_zhu", "lipophilicity_astrazeneca",
       "ppbr_az", "solubility_aqsoldb", "vdss_lombardo"}

# 重尾回归任务：在对数域拟合（排序指标对单调变换不变）
LOG_T = {"clearance_hepatocyte_az", "clearance_microsome_az",
         "half_life_obach", "vdss_lombardo"}

REF = {"ames": 0.871945, "bbb_martins": 0.927779, "bioavailability_ma": 0.722248,
       "caco2_wang": 0.283647, "clearance_hepatocyte_az": 0.55204,
       "clearance_microsome_az": 0.642814,
       "cyp2c9_substrate_carbonmangels": 0.44337, "cyp2c9_veith": 0.790586,
       "cyp2d6_substrate_carbonmangels": 0.747531, "cyp2d6_veith": 0.719172,
       "cyp3a4_substrate_carbonmangels": 0.725249, "cyp3a4_veith": 0.884121,
       "dili": 0.908609, "half_life_obach": 0.49139, "herg": 0.863358,
       "hia_hou": 0.99428, "ld50_zhu": 0.603071,
       "lipophilicity_astrazeneca": 0.472895, "pgp_broccatelli": 0.938363,
       "ppbr_az": 7.330617, "solubility_aqsoldb": 0.738443,
       "vdss_lombardo": 0.660995}

DESC = [("MolWt", Descriptors.MolWt), ("MolLogP", Descriptors.MolLogP),
        ("TPSA", Descriptors.TPSA), ("HDon", Descriptors.NumHDonors),
        ("HAcc", Descriptors.NumHAcceptors), ("RotB", Descriptors.NumRotatableBonds),
        ("Rings", Descriptors.RingCount), ("Arom", Descriptors.NumAromaticRings),
        ("CSP3", Descriptors.FractionCSP3), ("Heavy", Descriptors.HeavyAtomCount),
        ("Bertz", Descriptors.BertzCT), ("MolMR", Descriptors.MolMR),
        ("Chiral", Descriptors.NumAtomStereoCenters),
        ("Amide", Descriptors.NumAmideBonds)]

_CACHE = {}


def featurize(smi):
    if smi in _CACHE:
        return _CACHE[smi]
    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        v = np.zeros(2048 + 167 + len(DESC), dtype=np.float32)
    else:
        fp = AllChem.GetMorganFingerprintAsBitVect(mol, 2, nBits=2048)
        a = np.zeros(2048, dtype=np.float32)
        for i in fp.GetOnBits():
            a[i] = 1.0
        maccs = np.array(MACCSkeys.GenMACCSKeys(mol), dtype=np.float32)
        d = np.array([f(mol) for _, f in DESC], dtype=np.float32)
        d = np.nan_to_num(d, nan=0.0, posinf=0.0, neginf=0.0)
        v = np.concatenate([a, maccs, d])
    _CACHE[smi] = v
    return v


def scaffold(smi):
    mol = Chem.MolFromSmiles(smi)
    if mol is None:
        return smi
    try:
        return MurckoScaffold.MurckoScaffoldSmiles(mol=mol, includeChirality=False)
    except Exception:
        return smi


def rd(p):
    with open(p, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def score_of(raw, ref, met):
    if met in ("AUROC", "AUPRC"):
        return 50 + 25 * np.log(max(raw, 1e-12) / ref)
    if met == "MAE":
        return 50 + 25 * np.log(ref / max(raw, 1e-12))
    return 50 + 25 * np.log((1 + raw) / (1 + ref))


def auc(y, p):
    from sklearn.metrics import roc_auc_score
    return float(roc_auc_score(y, p))


def auprc(y, p):
    from sklearn.metrics import average_precision_score
    return float(average_precision_score(y, p))


def spearman(y, p):
    from scipy.stats import spearmanr
    return float(spearmanr(y, p).statistic)


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--ds", default="ds/data_benchmark")
    ap.add_argument("--out", default="submission_model.csv")
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--seed", type=int, default=20261107)
    ap.add_argument("--report", default="cv_report.json")
    a = ap.parse_args()

    import lightgbm as lgb
    from sklearn.metrics import mean_absolute_error

    report = {}
    preds = {}
    print(f"{'task':<34}{'n_tr':>7}{'pos%':>6}{'folds':>6}{'OOF':>9}{'score':>9}")
    for t in ORDER:
        tr = rd(os.path.join(a.ds, t, "train.csv"))
        va = rd(os.path.join(a.ds, t, "valid.csv"))
        te = rd(os.path.join(a.ds, t, "test.csv"))
        rows = tr + va
        X = np.stack([featurize(r["Drug"]) for r in rows])
        y = np.array([float(r["Y"]) for r in rows])
        smi = [r["Drug"] for r in rows]
        Xt = np.stack([featurize(r["Drug"]) for r in te])

        met = METRIC[t]
        is_cls = t not in REG
        log_t = t in LOG_T
        yfit = np.log(y) if log_t else y
        obj = ("binary" if is_cls else
               "regression_l1" if met == "MAE" else "regression")

        # 骨架分组折
        groups = np.array([scaffold(s) for s in smi])
        ug = {}
        for i, g in enumerate(groups):
            ug.setdefault(g, []).append(i)
        keys = sorted(ug.keys())
        rng = np.random.default_rng(a.seed + ORDER.index(t))
        rng.shuffle(keys)
        fold_of_group = {g: i % a.folds for i, g in enumerate(keys)}
        fid = np.array([fold_of_group[g] for g in groups])

        params = dict(objective=obj,
                      learning_rate=0.05, num_leaves=31, min_child_samples=10,
                      feature_fraction=0.4, bagging_fraction=0.8, bagging_freq=1,
                      lambda_l2=1.0, verbose=-1, num_threads=8, seed=a.seed)
        if is_cls:
            params["metric"] = "average_precision" if met == "AUPRC" else "auc"
        elif met == "MAE":
            params["metric"] = "l1"
        else:
            params["metric"] = "l2"

        oof = np.zeros(len(rows))
        its = []
        for f in range(a.folds):
            ti = np.where(fid != f)[0]
            vi = np.where(fid == f)[0]
            if len(vi) < 5:
                continue
            ds_tr = lgb.Dataset(X[ti], label=yfit[ti])
            ds_va = lgb.Dataset(X[vi], label=yfit[vi])
            m = lgb.train(params, ds_tr, num_boost_round=3000, valid_sets=[ds_va],
                          callbacks=[lgb.early_stopping(100, verbose=False)])
            oof[vi] = m.predict(X[vi], num_iteration=m.best_iteration)
            its.append(m.best_iteration)

        oof_orig = np.exp(oof) if log_t else oof
        if met == "AUROC":
            raw_oof = auc(y, oof)
        elif met == "AUPRC":
            raw_oof = auprc(y, oof)
        elif met == "MAE":
            raw_oof = float(mean_absolute_error(y, oof))
        else:
            raw_oof = spearman(y, oof_orig)
        s = score_of(raw_oof, REF[t], met)

        # 全量重训
        n_iter = max(int(np.mean(its)) if its else 500, 50)
        full = lgb.train(params, lgb.Dataset(X, label=yfit), num_boost_round=n_iter)
        p = full.predict(Xt)
        if is_cls:
            p = np.clip(p, 0.0, 1.0)
        elif log_t:
            p = np.exp(p)
        preds[t] = p
        pos = f"{y.mean()*100:.1f}" if is_cls else "-"
        print(f"{t:<34}{len(rows):>7}{pos:>6}{a.folds:>6}{raw_oof:>9.4f}{s:>9.3f}")
        report[t] = {"metric": met, "n_train": len(rows), "n_test": len(te),
                     "oof": raw_oof, "oof_score": s, "n_iter": n_iter,
                     "oof_pred": oof.tolist()}

    tot = sum(v["oof_score"] for v in report.values()) / len(ORDER)
    print(f"{'OOF TOTAL':<34}{'':>7}{'':>6}{'':>6}{'':>9}{tot:>9.3f}")
    report["_total_oof"] = tot

    # 写提交
    with open(a.out, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
        w.writerow(["task", "sample_idx", "drug_id", "smiles", "y_pred", "metric"])
        for t in ORDER:
            for i, r in enumerate(rd(os.path.join(a.ds, t, "test.csv"))):
                w.writerow([t, i, r["Drug_ID"], r["Drug"],
                            repr(float(preds[t][i])), METRIC[t]])
    print(f"已写出 {a.out}")

    with open(a.report, "w", encoding="utf-8") as f:
        json.dump(report, f)
    print(f"已写出 {a.report}")


if __name__ == "__main__":
    main()
