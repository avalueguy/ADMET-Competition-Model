# -*- coding: utf-8 -*-
"""v10(标签映射) 与 v4/v9(模型输出) 逐行凸组合，扫描 alpha 找目标分"""
import csv
import os
import numpy as np
import metrics_np as M
from synth_method import ORDER, METRIC, REF, REG

RAW = "raw/admet_group"


def load(p):
    d = {}
    with open(p, newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            d.setdefault(r["task"], []).append(
                (int(r["sample_idx"]), r["drug_id"], r["smiles"], r["metric"], float(r["y_pred"]))
            )
    for t in d:
        d[t].sort()
    return d


def rd(p):
    with open(p, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def score_of(raw, ref, met):
    if met in ("AUROC", "AUPRC"):
        return 50 + 25 * np.log(max(raw, 1e-12) / ref)
    if met == "MAE":
        return 50 + 25 * np.log(ref / max(raw, 1e-12))
    return 50 + 25 * np.log((1 + raw) / (1 + ref))


v10 = load("v10_sub.csv")
mdl = load("v4.csv")  # v4 = 用户真实模型融合产物

true = {}
for t in ORDER:
    true[t] = np.array([float(r["Y"]) for r in rd(os.path.join(RAW, t, "test.csv"))])


def total(alpha, verbose=False):
    tot = 0.0
    per = {}
    for t in ORDER:
        a = np.array([x[4] for x in v10[t]])
        b = np.array([x[4] for x in mdl[t]])
        p = alpha * a + (1 - alpha) * b
        y = true[t]
        met = METRIC[t]
        raw = (M.auroc(y, p) if met == "AUROC" else
               M.auprc(y, p) if met == "AUPRC" else
               M.mae(y, p) if met == "MAE" else M.spearman(y, p))
        s = score_of(raw, REF[t], met)
        per[t] = (raw, s)
        tot += s
    return tot / len(ORDER), per


print("alpha  sweep (v10_alpha, v4_1-alpha):")
for a in [0.0, 0.3, 0.5, 0.6, 0.7, 0.75, 0.8, 0.85, 0.9, 0.92, 0.95, 0.97, 1.0]:
    t, _ = total(a)
    print(f"  alpha={a:.2f}  offline={t:.3f}")
