# -*- coding: utf-8 -*-
"""融合 GBM 与 GNN 的 OOF/test 预测，选权重，产出提交文件"""
import json, argparse
import numpy as np
import pandas as pd
from pathlib import Path
import common
from common import REF, METRIC, LOG_TARGET, score_metric, comp_score, load_task, ROOT

RUNS = ROOT / "runs"
ALPHAS = np.arange(0.0, 1.001, 0.05)


def load_model(kind, task):
    f = RUNS / kind / f"{task}_{kind}.npz"
    if not f.exists():
        return None
    return dict(np.load(f))


def guided_blend(o1, o2, alpha):
    return alpha * o1 + (1 - alpha) * o2


def rank(v):
    from scipy.stats import rankdata
    return rankdata(v) / len(v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="final")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    tpl = pd.read_csv(ROOT / "upload_template.csv")
    tasks_in_order = list(dict.fromkeys(tpl["task"].tolist()))
    report, ypred_all = [], {}

    for task in tasks_in_order:
        metric = METRIC[task]; ref = REF[task]
        kind = "cls" if metric in ("AUROC", "AUPRC") else "reg"
        tr, va, te = load_task(task)
        nte = len(te)

        cands = {}
        g = load_model("gbm", task)
        n = load_model("gnn", task)
        if g is not None:
            cands["gbm"] = g
        if n is not None and (g is None or len(n["y"]) == len(g["y"])):
            cands["gnn"] = n
        if not cands:
            print(f"[miss] {task}"); continue

        if len(cands) == 1:
            k0 = list(cands)[0]
            oof = cands[k0]["oof"]; test = cands[k0]["test"]
            best_oof_m = score_metric(cands[k0]["y"], oof, metric)
            best_desc = k0
        else:
            y = cands["gbm"]["y"]
            o1, o2 = cands["gbm"]["oof"], cands["gnn"]["oof"]
            t1, t2 = cands["gbm"]["test"], cands["gnn"]["test"]
            sign = -1.0 if metric == "MAE" else 1.0
            best = None
            for mode in ("raw", "rank"):
                for al in ALPHAS:
                    if mode == "raw":
                        bo = guided_blend(o1, o2, al)
                    else:
                        bo = guided_blend(rank(o1), rank(o2), al)
                    v = score_metric(y, bo, metric)
                    if not np.isfinite(v):
                        continue
                    if best is None or v * sign > best[0] * sign:
                        best = (v, mode, al)
            best_oof_m, mode, al = best
            best_desc = f"gbm*{al:.2f}+gnn*{1-al:.2f}({mode})"
            if mode == "raw":
                oof = guided_blend(o1, o2, al); test = guided_blend(t1, t2, al)
            else:
                oof = guided_blend(rank(o1), rank(o2), al)
                test = guided_blend(rank(t1), rank(t2), al)
            # 只用 GBM 或只用 GNN 作对比
            m1 = score_metric(y, o1, metric); m2 = score_metric(y, o2, metric)
            # 若单一模型更好，退回单一
            if m1 * sign > best_oof_m * sign:
                best_oof_m, best_desc, oof, test = m1, "gbm_only", o1, t1
            if m2 * sign > best_oof_m * sign:
                best_oof_m, best_desc, oof, test = m2, "gnn_only", o2, t2

        # 回归裁剪到训练标签范围内（不越过物理边界，避免离群预测拉高 MAE）
        if kind == "reg":
            yv = np.concatenate([tr["Y"].values.astype(float), va["Y"].values.astype(float)])
            lo, hi = np.nanmin(yv), np.nanmax(yv)
            span = hi - lo
            test = np.clip(test, lo - 0.02 * span, hi + 0.02 * span)
            if task in LOG_TARGET:
                pass
        else:
            test = np.clip(test, 0.0, 1.0)

        assert len(test) == nte, f"{task}: {len(test)} vs {nte}"
        assert np.all(np.isfinite(test)), f"{task}: 非有限预测"
        ypred_all[task] = test
        cs = comp_score(best_oof_m, metric, ref)
        report.append(dict(task=task, metric=metric, ref=ref, n_test=nte,
                           blend=best_desc, oof_metric=round(float(best_oof_m), 4),
                           score=round(float(cs), 3)))

    df = pd.DataFrame(report)
    print(df.to_string(index=False))
    total = df["score"].mean()
    print(f"\n[projected] OOF 估计总分 = {total:.3f}   (当前线上 51.314)")

    # 写提交
    yv = []
    for task, g in tpl.groupby("task", sort=False):
        yv.extend(ypred_all[task].tolist())
    assert len(yv) == len(tpl), f"{len(yv)} vs {len(tpl)}"
    out = tpl.copy()
    out["y_pred"] = yv
    outp = Path(a.out) if a.out else (ROOT / f"submission_{a.tag}.csv")
    out.to_csv(outp, index=False)
    report_p = ROOT / f"report_{a.tag}.csv"
    df.to_csv(report_p, index=False)
    with open(ROOT / f"report_{a.tag}.json", "w") as f:
        json.dump(dict(total=float(total), rows=report), f, indent=2, ensure_ascii=False)
    print(f"\n[saved] {outp}  rows={len(out)}")
    print(f"[saved] {report_p}")
    print(f"[check] 空值={out['y_pred'].isna().sum()} 列={list(out.columns)}")


if __name__ == "__main__":
    main()
