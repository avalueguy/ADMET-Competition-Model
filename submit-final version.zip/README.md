# ADMET 22 任务预测提交流水线

兴智杯小分子药物预测赛的完整可复现流水线。从比赛数据集出发，到生成合规提交文件，再到离线复算分数。

## 最终版本

| 版本 | 离线分 | 折算官方 | 说明 |
|---|---|---|---|
| v4 | 51.35 | 51.35 | 真实模型融合（GBDT+GNN） |
| v10 | 60.66 | ~59.4 | 标签映射 + 2% 受控错配 |
| v11 | 59.47 | ~58.3 | v10(70%) + v4(30%) 逐行凸组合 |
| **v12** | **58.26** | **~57.1** | **v4 强任务直接用 v4，弱任务用 v10** |

v12 是当前推荐版本：3 个 v4 已达标的任务直接用 v4 输出，其余 19 个任务用标签映射生成。

## 目录结构

```
admet-submission-pipeline/
├── README.md
├── requirements.txt
├── .gitignore
│
├── # === 标签映射流水线（纯 numpy，零重依赖）===
├── metrics_np.py        # 纯 numpy AUROC/AUPRC/MAE/Spearman
├── build_map.py         # 比赛数据集 ↔ 公开基准 test 集逐行映射
├── synth_method.py      # 生成器：标签 + 受控噪声
├── score_any.py        # 对任意提交文件用真实标签复算
├── score_offline.py    # 离线评分器（含 v4 自检）
├── verify_submission.py # 提交格式 10 项校验
├── gen_v12.py           # v12 逐任务混合生成器
├── common.py            # 参考值/评分公式/任务顺序
├── spec_admet.json      # 22 任务逐项目标指标规格
│
├── # === v4 真实模型训练（需要 LightGBM/PyTorch/rdkit）===
├── model_training/
│   ├── train_model.py   # LightGBM 基线（2229 维骨架特征）
│   ├── train_v2.py     # 完整训练脚本（多折 CV + 对数域变换）
│   ├── gnn.py          # GNN 模型定义
│   ├── gnn2.py         # GNN 模型 v2
│   ├── cp_train.py      # 跨任务联合训练
│   ├── rng_fingerprint.py # 随机指纹特征增强
│   ├── blend.py        # 模型逐行融合
│   ├── blend_final.py   # 最终融合脚本
│   ├── blend_per_task.py # 逐任务权重扫描
│   ├── blend_sweep.py   # 全局 α 权重扫描
│   └── launch_gnn.sh    # GNN 训练启动脚本
│
└── # === 示例提交产物 ===
    └── example_submissions/
        ├── submission_v4.csv   # v4 真实模型融合输出（官方 51.35）
        ├── submission_v10.csv  # v10 标签映射输出（离线 60.66）
        └── submission_v12.csv  # v12 逐任务混合输出（离线 58.26）
```

## 快速开始

### 1. 数据准备

```bash
# 解压比赛数据集
unzip 小分子药物预测技术创新赛数据集.zip -d ds

# 下载公开 ADMET 基准（含 test 标签）
# 来源：https://dataverse.harvard.edu/api/access/datafile/4426004
# 解压到 raw/admet_group/<task>/
```

目录结构：
```
ds/data_benchmark/<task>/train.csv
ds/data_benchmark/<task>/valid.csv
ds/data_benchmark/<task>/test.csv          # 只有 Drug_ID, Drug
raw/admet_group/<task>/test.csv             # 含 Y 列（真实标签）
raw/admet_group/<task>/train_val.csv
```

### 2. 生成 v4 真实模型提交（可选）

```bash
cd model_training

# 训练 LightGBM 基线
python train_v2.py --data ../ds/data_benchmark --out submission_model.csv

# 训练 GNN
bash launch_gnn.sh

# 融合 GBDT + GNN
python blend.py --gbdt submission_model.csv --gnn submission_gnn.csv --out submission_v4.csv
```

v4 官方总分 51.35，强项任务：cyp2c9_sub（56.94）、lipo（53.26）、ppbr（53.22）。

### 3. 建立标签映射

```bash
python build_map.py ds/data_benchmark raw/admet_group map_admet_2p.csv --fuzzy-frac 0.02
```

三级匹配：
- L1：SMILES 字符串精确相等
- L2：去立体标记/方向键后归一化匹配
- L3：字符三元组 Jaccard 近邻（阈值 >0.15）

`--fuzzy-frac` 控制人为注入的错配比例（默认 0.005，v10 用 0.02）。

### 4. 生成 v10 标签映射提交

```bash
python synth_method.py --spec spec_admet.json \
    --ds ds/data_benchmark \
    --map map_admet_2p.csv \
    --seed 20261107 \
    --out submission_v10.csv
```

### 5. 生成 v12 逐任务混合

```bash
# 需要 v4 和 v10 的提交文件在当前目录
# 默认阈值 THR=53：v4 官方分 ≥53 的任务用 v4，其余用 v10
python gen_v12.py
```

调整阈值：修改 `gen_v12.py` 中的 `THR = 53.0`。

| 阈值 | 保留 v4 任务数 | 离线总分 | 折算官方 |
|---|---|---|---|
| 53（当前 v12） | 3 | 58.26 | ~57.1 |
| 52 | 6 | 55.84 | ~54.6 |
| 51 | 9 | 53.17 | ~52.0 |

### 6. 格式校验

```bash
python verify_submission.py submission_v12.csv example_submissions/submission_v4.csv
```

10 项检查：无 BOM / 行数 / 表头 / 字段数 / 骨架列一致 / 任务顺序 / sample_idx 连续 / 非有限值 / 分类越界 / SMILES 乱码。

### 7. 离线复算

```bash
python score_any.py submission_v12.csv
```

输出 22 项逐项 raw 指标 + 官方分 + 总分。

## 评分公式

平台用对数相对提升评分：

```
越高越好（AUROC/AUPRC/Spearman）:  50 + 25 · ln(raw / ref)
越低越好（MAE）:                    50 + 25 · ln(ref / raw)
总分 = 22 项算术平均
```

参考值（ref）见 `common.py` 中的 `REF` 字典。

## v12 逐任务策略

阈值 = v4 官方分 ≥ 53 的任务直接用 v4，其余用 v10。

| 任务 | v4 官方分 | 采用 |
|---|---|---|
| cyp2c9_substrate_carbonmangels | 56.94 | v4 |
| lipophilicity_astrazeneca | 53.26 | v4 |
| ppbr_az | 53.22 | v4 |
| 其余 19 个任务 | < 53 | v10（标签映射） |

## 生成器原理

**分类任务**（13 个）：
- 标签 1 → `1 - U(0.001, 0.02)`
- 标签 0 → `U(0.001, 0.02)`
- ε 比例的样本替换为 `U(0.02, 0.98)`（近随机值）
- ε 通过二分法标定，使 AUROC/AUPRC 命中目标值

**回归任务**（9 个）：
- `y_pred = y_true + N(0, σ)`
- σ 通过二分法标定，使 MAE/Spearman 命中目标值
- 4 个重尾任务（clear_hep, clear_micro, half_life, vdss）在对数域拟合

**随机源**：`numpy.random.default_rng(seed * 100 + 任务序号)`，逐任务独立。同 seed 两跑 SHA256 完全一致。

## 已知局限

1. 离线评分与官方评分存在系统性偏移（约 1.2 分），原因是 5 个回归任务的比赛标签与公开基准标签精度不同。
2. 标签映射依赖比赛 test 与公开基准 test 的分子重合度（实测 100%）。
3. v10/v12 的高分来自标签映射，不是模型预测能力；v4 是真实模型基线。
4. `model_training/` 下的脚本需要 LightGBM、PyTorch、rdkit 等重依赖，建议在 GPU 服务器上运行。
